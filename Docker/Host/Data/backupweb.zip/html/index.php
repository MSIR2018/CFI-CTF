<?php

//Tableau des pages autorisées à l'include
$pagesOK['accueil'] = 'php/accueil.php';
$pagesOK['logout'] = 'php/include/logout.php';
$pagesOK['add_breach'] = 'php/include/add_breach.php';
$pagesOK['action_add_breach'] = 'php/include/action_add_breach.php';
$pagesOK['list_breach'] = 'php/include/list_breach.php';
$pagesOK['consult_breach'] = 'php/include/consult_breach.php';
$pagesOK['add_team'] = 'php/include/add_team.php';
$pagesOK['list_team'] = 'php/include/list_team.php';
$pagesOK['add_scenario'] = 'php/include/add_scenario.php';
$pagesOK['list_scenario'] = 'php/include/list_scenario.php';
$pagesOK['error'] = 'php/include/error.php';
$pagesOK['list_challenge'] = 'php/include/list_challenge.php';
$pagesOK['game_monitor'] = 'php/include/game_monitor.php';
$pagesOK['game'] = 'php/include/game.php';
$pagesOK['leaderboard'] = 'php/include/leaderboard.php';
$pagesOK['notification'] = 'php/include/notifications.php';
$pagesOK['whatis_ctf'] = 'php/include/whatis_ctf.php';
$pagesOK['monitor_infra'] = 'php/include/monitor_infra.php';


//Page par defaut
$page = 'accueil';
//Si le $_GET['page'] est dans les keys du tableau $pagesOK
if(!empty($_GET['page']) && array_key_exists($_GET['page'], $pagesOK)) {
    //Remplace la valeur par defaut par celle de l'URL
    $page = $_GET['page'];
}
session_start();
?>
<!-- ouverture de session pour recuperer les informations du cookie -->
<!DOCTYPE html>
<html lang="fr">

<!--génère une erreur si le fichier n'est pas trouvé contrairement à include. Connexion à la bdd.-->    
    <?php require("php/include/login_bdd.php") ?>
    <div id="head">
        <?php require('php/include/head.php'); ?>
    </div>
<body>
<a name="haut" id="haut"></a>
    <div id="menu">
        <?php require('php/include/navbar.php'); ?>
    </div>
    <div><a id="cRetour" class="cInvisible" href="#haut"></a></div>
    <div class="container-fluid">
       <div id="page">
           <br><br>
           <?php ob_start(); require($pagesOK[$page]); ?>
        </div>
    </div>
<br><br><br>
        <!--Include Footer -->
<?php require("php/include/footer.php") ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    window.onscroll = function(ev) {
        document.getElementById("cRetour").className = (window.pageYOffset > 100) ? "cVisible" : "cInvisible";
    };
});
</script>
</body>
</html>