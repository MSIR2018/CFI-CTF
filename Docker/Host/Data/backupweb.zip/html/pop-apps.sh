action=$1
appname=$2
appteamA=$2'_a'
appteamB=$2'_b'

if [ $action == 'create' ]; then

	if [ "$( echo $appname | grep win )" ]; then
	
		if [ "$( echo $appname | grep winxp )" ]; then flavor=winxp ;fi
		if [ "$( echo $appname | grep win7 )" ]; then flavor=win7 ;fi
	
		if [ -z "$(virsh list | grep $appteamA)" ];then
			cp -f /var/lib/libvirt/images/$flavor'_a'.dsk.save /var/lib/libvirt/images/$flavor'_a'.dsk
			virt-install  --bridge=br301 --name=$appteamA  --ram=2048  --graphics=vnc --noautoconsole --import --vcpus=2 --virt-type=kvm --os-type=windows --os-variant=$flavor  --boot hd --disk path=/var/lib/libvirt/images/$flavor'_a'.dsk,size=4
		else
			echo 'Deja crée'
		fi
		
		if [ -z "$(virsh list | grep $appteamB)" ];then
			cp -f /var/lib/libvirt/images/$flavor'_b'.dsk.save /var/lib/libvirt/images/$flavor'_b'.dsk
			virt-install  --bridge=br302 --name=$appteamB  --ram=2048  --graphics=vnc --noautoconsole --import --vcpus=2 --virt-type=kvm --os-type=windows --os-variant=$flavor  --boot hd --disk path=/var/lib/libvirt/images/$flavor'_b'.dsk,size=4
		else
			echo 'Deja crée'
		fi
	else
		if [ -z "$(docker ps | grep $appteamA)" ];then

			if [ "$(docker build https://github.com/MSIR2018/CFI-CTF.git#master:Docker/Challenges/$appname/TeamA -t $appteamA 2> /dev/null)" ]; then
					docker run -d --name=$appteamA -h $appteamA --restart=always --net=teamA $appteamA > /dev/null
					ip=$(docker inspect --format='{{.NetworkSettings.Networks.teamA.IPAddress}}' $appteamA)
					echo -e "TeamA: http://$ip"
			else
					echo 'NOT FOUND TeamA'
			fi
	   else
			ip=$(docker inspect --format='{{.NetworkSettings.Networks.teamA.IPAddress}}' $appteamA)
			echo -e "TeamA: http://$ip"
	   fi

	   if [ -z "$(docker ps | grep $appteamB)" ];then

			if [ "$(docker build https://github.com/MSIR2018/CFI-CTF.git#master:Docker/Challenges/$appname/TeamB -t $appteamB 2> /dev/null)" ]; then
					docker run -d --name=$appteamB -h $appteamB --restart=always --net=teamB $appteamB > /dev/null
					ip=$(docker inspect --format='{{.NetworkSettings.Networks.teamB.IPAddress}}' $appteamB)
					echo -e "TeamB: http://$ip"
			else
					echo 'NOT FOUND TeamB'
			fi
	   else
			ip=$(docker inspect --format='{{.NetworkSettings.Networks.teamB.IPAddress}}' $appname)
			echo -e "TeamB: http://$ip"
	   fi
	fi
fi

if [ $action == 'remove' ]; then
	if [ "$( echo $appname | grep win )" ]; then
		virsh -c qemu:///system undefine $appteamA && virsh destroy $appteamA
		virsh -c qemu:///system undefine $appteamB && virsh destroy $appteamB
	else
		docker rm -f $appteamA $appteamB

	fi
fi

if [ $action == 'purge' ]; then
docker rmi -f $appteamA $appteamB
fi

if [ $action == 'list' ]; then
	docker inspect --format='{{.Name}};{{.State.Status}};{{.State.StartedAt}};{{.State.FinishedAt}};{{.NetworkSettings.Networks.teamA.IPAddress}};{{.NetworkSettings.Networks.teamB.IPAddress}}' $(docker ps -aq) | sort
	virsh list --all | grep _ | awk '{print "/"$2";"$3.$4";0;0;0;0" }'
fi

