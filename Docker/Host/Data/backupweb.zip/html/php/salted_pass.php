<html>
<center>
<form action="salted_pass.php" method="post">
    Mot de passe:
    <input type="text" name="pass">
    Salt:
    <input type="text" name="salt">
    <input type="submit" name="form">
</form>
    <?php
    if(isset($_POST['form'])){
        $pass=md5($_POST['pass']);
        $salt=$_POST['salt'];
        $salted_pass=$pass.$salt;
        $md5saltedpass=md5($salted_pass);

        echo 'pass: '.$_POST['pass'].'</br>';
        echo 'salt: '.$_POST['salt'].'</br>';

        echo 'md5_pass: '.$pass.'</br>';
        echo 'salted_pass: '.$salted_pass.'</br>';
        echo '<b>md5_salted_pass: '.$md5saltedpass.'</b></br>';
    } ?>
</center>
</html>