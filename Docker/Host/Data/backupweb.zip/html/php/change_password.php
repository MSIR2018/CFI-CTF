<?php if (isset($_SESSION['login']) and ($_SESSION['connected'] == 'yes')){

    if (isset($_POST['form'])){
        $login=$_SESSION['login'];
        $pass=$_POST['pass'];

        $pass=md5($_POST['pass']);
        $salt=$_SESSION['login'];
        $salted_pass=$pass.$salt;
        $pass=md5($salted_pass);
        $id_etud=$_SESSION['id_etudiant'];

        include('bdd_connect.php');
        $requete="update etudiant set etud_mdp = :pass, etud_mdpupdate = DATE(now()) where id_etudiant=:id_etudiant ;";
        $donnees=array(":id_etudiant"=>$id_etud,":pass"=>$pass);
        $resultat=$connexion->prepare($requete);
        $resultat->execute($donnees);

        $ligne=$resultat->fetch();

        ?><center><div class="alert alert-success" role="alert">Votre mot de passe à bien été mis à jour</div>
        <div class="col-sm-4 col-sm-offset-4"><a href="index.php"><button type="button" class="btn btn-default form-control" >Retour</button></a></div><br></center><?php
        session_destroy();

    }


    ?>
    <script language="JavaScript">
        function randomPassword(length)
        {
            chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            pass = "";
            for(x=0;x<length;x++)
            {
                i = Math.floor(Math.random() * 62);
                pass += chars.charAt(i);
            }

            document.getElementById('pass').value = pass;
        }
    </script>

    <div class="container" style="margin-bottom: 20px;">
    <br>
    <div class="col-sm-10 ">
        <div class="panel panel-primary">
            <div class="panel-heading" style="height: 60px;">
                <h3 class="panel-title pull-left" style="margin-top: 10px">Bienvenue <?php echo $_SESSION['prenom'] ?></h3>
                <h3 class="panel-title pull-right"><a href="index.php?action=logout"><button type="button" class="btn btn-danger">Se deconnecter</button></a></h3>
                <br>
            </div>
            <div class="panel-body">
                <form action="index.php?action=changepassword" class="col-sm-6 col-sm-offset-3" method="post">
                    <div class="col-sm-12" style="margin-bottom: 5px">
                        <label for="pass">Votre nouveau mot de passe: </label>
                        <input type="text" name="pass" id="pass" class="form-control">
                    </div>
                    <div class="col-sm-12" style="margin-bottom: 5px"><button type="button" class="btn btn-primary form-control" onclick="randomPassword(10)">Generer un mot de passe Aléatoire</button></div>
                    <div class="col-sm-6"><a href="index.php"><button type="button" class="btn btn-default form-control" >Retour</button></a></div>
                    <div class="col-sm-6"><input type="submit" name="form" class="form-control btn-success"></div>
                </form>
            </div>
        </div>
    </div>
    </div><?php }else { header('Location: index.php?action=error'); } ?>
