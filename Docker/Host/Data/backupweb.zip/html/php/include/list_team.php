<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){ ?><div class="container"><?php
require("php/include/login_bdd.php");
if(isset($_POST['form'])){
    if($_POST['action'] == "delete"){ //mode delete
        $delete = $connexion->prepare('DELETE FROM equipes WHERE id = :id');
        $delete->execute(array(
            'id' => $_POST['id']));
    }
}

if(isset($_GET['delete'])){
$equipes = $connexion->query('SELECT * FROM equipes WHERE id='.$_GET['delete'].' ORDER BY id');
foreach($equipes as $equipe){
?>
<form action="index.php?page=list_team" method="post">
    <input type="hidden" name="action" id="action" value="delete" />
    <input type="hidden" name="id" id="id" value="<?php echo $equipe['id']; ?>" />
    <legend style="text-align: left;">Supprimer l'équipe</legend>
    <div class="alert alert-warning text-center">
        <div>
            <p><strong>Warning:</strong> Etes vous sûr de vouloir supprimer l'equipe <?php echo $equipe['team_name']; ?> ?
                <a href="index.php?page=list_team" class="pull-right"><button name="form" style="margin-left:10px;" class="btn btn-danger" type="button" value="Non">Non</button></a>
                <a class="pull-right"><button name="form" class="btn btn-success" style="margin-left:10px;" type="submit" value="Oui">Oui</button></a>
            </p>
        </div>
    </div>
</form>
    <?php } }else{
$reponse = $connexion->prepare('SELECT * FROM equipes ORDER BY team_name ASC');
$reponse ->execute();
?>
    <div class="row">
        <div class="col-md-12">
            <!-- Form Name -->
            <legend>Liste des équipes</legend>
            <?php
            while ($donnees = $reponse->fetch()){
            ?>
            <div class="panel-group" id="panel-<?php echo $donnees['id'];?>">
                <div class="panel panel-default">
                    <div class="panel-heading" style="height: 60px;">
                        <a class="panel-title pull-left" data-toggle="collapse" data-parent="#panel-<?php echo $donnees['id'];?>" href="#panel-element-<?php echo $donnees['id'];?>"><img src="ressources/logo_equipes/logo<?php echo $donnees['team_logo'];?>.png" alt="" style="width: 25px">  Equipe - <?php echo $donnees['team_name'];?></a>
                        <h3 class="panel-title pull-right">
                            <a href="index.php?page=list_team&delete=<?php echo $donnees['id'];?>"><i class="fa fa-trash" style="font-size:15px" ></i></a>
                            <a href="index.php?page=add_team&edit=<?php echo $donnees['id'];?>"><i class="fa fa-cog" style="font-size:15px" ></i></a>
                        </h3>
                    </div>
                    <div id="panel-element-<?php echo $donnees['id'];?>" class="panel-collapse collapse">
                        <div class="panel-body">

                            <table class="table table-user-information">
                                <tbody>
                                <tr>
                                    <td>Nom de l'équipe : </td>
                                    <td><?php echo $donnees['team_name'];?></td>
                                </tr>
                                <tr>
                                    <td>Membre de l'équipe : </td>
                                    <td><?php echo $donnees['team_member'];?></td>
                                </tr>
                                <tr>
                                    <td>Description de l'équipe : </td>
                                    <td><?php echo $donnees['team_desc'];?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
                <?php
            }
            ?>
        </div>

    </div>
<?php } ?></div><?php
    }else{
        echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
    }
    ?>