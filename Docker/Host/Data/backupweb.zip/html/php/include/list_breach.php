<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){ ?><div class="container"><?php
require("php/include/login_bdd.php");
if(isset($_POST['form'])){
if($_POST['action'] == "delete"){ //mode delete
    $delete = $connexion->prepare('DELETE FROM breach WHERE id = :id');
    $delete->execute(array(
        'id' => $_POST['id']));
    }
}

if(isset($_GET['delete'])){
$breachs = $connexion->query('SELECT * FROM breach WHERE id='.$_GET['delete'].' ORDER BY id');
foreach($breachs as $breach){
?>
<form action="index.php?page=list_breach" method="post">
    <input type="hidden" name="action" id="action" value="delete" />
    <input type="hidden" name="id" id="id" value="<?php echo $breach['id']; ?>" />
    <legend style="text-align: left;">Supprimer la faille</legend>

    <div class="alert alert-warning text-center">
        <div>
            <p><strong>Warning:</strong> Etes vous sûr de vouloir supprimer <?php echo $breach['breach_name']; ?> ?
                <a href="index.php?page=list_breach" class="pull-right"><button name="form" style="margin-left:10px;" class="btn btn-danger" type="button" value="Non">Non</button></a>
                <a class="pull-right"><button name="form" class="btn btn-success" style="margin-left:10px;" type="submit" value="Oui">Oui</button></a>
            </p>


        </div>
    </div>
</form>
    <?php } }else{
$reponse = $connexion->prepare('SELECT * FROM breach ORDER BY breach_type ASC');
$reponse ->execute();
?>
    <div class="row">
        <div class="col-md-12">
            <!-- Form Name -->
            <legend>Liste des failles (<span id="nb_breach"></span>)</legend>
            <?php ?>

            <div style="margin-bottom: 20px">
                <input class="form-control" id="myInput" type="text" placeholder="Rechercher une faille..">
            </div>
            <?php while ($donnees = $reponse->fetch()){
                ?>
                <div class="panel-group breach_name" id="panel-<?php echo $donnees['id'];?>" template-name="<?php echo $donnees['breach_type'];?>-<?php echo $donnees['breach_template'];?>" branch-name="<?php echo $donnees['breach_name'];?>" branch-desc="<?php echo $donnees['breach_desc'];?>">
                    <div class="panel panel-default">
                        <div class="panel-heading" style="height: 60px;">
                            <a class="panel-title pull-left" data-toggle="collapse" data-parent="#panel-<?php echo $donnees['id'];?>" href="#panel-element-<?php echo $donnees['id'];?>">Faille : <?php echo $donnees['breach_name'];?> (<?php echo $donnees['breach_type'];?>-<?php echo $donnees['breach_template'];?>)</a>
                            <h3 class="panel-title pull-right">
                                <a href="index.php?page=list_breach&delete=<?php echo $donnees['id'];?>"><i class="fa fa-trash" style="font-size:15px" ></i></a>
                                <a href="index.php?page=add_breach&edit=<?php echo $donnees['id'];?>"><i class="fa fa-cog" style="font-size:15px" ></i></a>
                            </h3>
                        </div>
                        <div id="panel-element-<?php echo $donnees['id'];?>" class="panel-collapse collapse">
                            <div class="panel-body">

                                <table class="table table-user-information">
                                    <tbody>
                                    <tr>
                                        <td>Nom de la faille : </td>
                                        <td><?php echo $donnees['breach_name'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Type de la faille : </td>
                                        <td><?php echo $donnees['breach_type'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Difficulté de la faille : </td>
                                        <td><?php echo $donnees['breach_difficulty'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Nombre de points : </td>
                                        <td><?php echo $donnees['breach_points'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Description de la faille : </td>
                                        <td><?php echo $donnees['breach_desc'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Template de la faille : </td>
                                        <td><?php echo $donnees['breach_type'];?>-<?php echo $donnees['breach_template'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Flag de la faille A : </td>
                                        <td><?php echo $donnees['breach_flag_a'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Flag de la faille B : </td>
                                        <td><?php echo $donnees['breach_flag_b'];?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>

    </div>
    <script>
        $(document).ready(function() {
            document.getElementById('myInput').onkeyup=function(){
                var input=document.getElementById('myInput').value;
                var nb = document.getElementsByClassName('breach_name').length
                var current = 0
                while(current<nb){
                    if(document.getElementsByClassName('breach_name')[current].getAttribute('branch-name').toLowerCase().includes(input.toLowerCase()) !== true && document.getElementsByClassName('breach_name')[current].getAttribute('template-name').toLowerCase().includes(input.toLowerCase()) !== true && document.getElementsByClassName('breach_name')[current].getAttribute('branch-desc').toLowerCase().includes(input.toLowerCase()) !== true){
                        document.getElementsByClassName('breach_name')[current].style.visibility = 'hidden';
                        document.getElementsByClassName('breach_name')[current].style.height = '0px';
                        document.getElementsByClassName('breach_name')[current].style.overflow = 'hidden';
                        document.getElementsByClassName('breach_name')[current].style.marginBottom = '0px';
                    }else{
                        document.getElementsByClassName('breach_name')[current].style = '';
                    }
                    current=current+1; }
            }
            document.getElementById('nb_breach').innerHTML=document.querySelectorAll('.breach_name').length
        });
    </script>

<?php } ?></div><?php
    }else{
        echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
    }
    ?>
