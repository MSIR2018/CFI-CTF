<!DOCTYPE html>
<html>

<head>
    <title>Footer with Button and Logo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Footer-with-button-logo.css">
</head>

<body>
<div class="content">
</div>
<footer id="myFooter">
    <div class="container container-transparent">
        <div class="row">
            <div class="col-sm-3">
                <h2 class="logo"><img alt="Bootstrap Image Preview" srcset="ressources/small.png 3000w" class="img-rounded" /></h2>
            </div>
            <div class="col-sm-2">
                <h5>Intro</h5>
                <ul>
                    <li><a href="index.php?page=accueil">Accueil</a></li>
                    <li><a href="index.php?page=login">Inscription</a></li>
                </ul>
            </div>
            <div class="col-sm-2">
                <h5>A propos</h5>
                <ul>
                    <li><a href="index.php?page=whatis_ctf">Company Information</a></li>
                    <li><a href="index.php?page=whatis_ctf">Contact us</a></li>
					<li><a href="https://www.afnic.fr/">Site de l'Afnic</a></li>
                </ul>
            </div>
            <div class="col-sm-2">
                <h5>Support</h5>
                <ul>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Help desk</a></li>
                    <li><a href="#">Forums</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
                <div class="social-networks">
                    <a href="#" class="twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="facebook"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="google"><i class="fab fa-google-plus"></i></a>
                </div>
                <button type="button" class="btn btn-default">Contact us</button>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <p>© 2018 Copyright MOBCZ </p>
    </div>
    <?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['connected']=='yes')){ ?>
    <script>
        function read_notif() {
            var path = "php/include/notifications.php";
            $.ajax({
                type: "POST",
                url: path,
                data: 'read',
                success: function (htmlResponse) {
                    if (htmlResponse == '') {
                        //document.getElementById('divteamA').innerHTML = '<div class=\"alert alert-info\">Aucune dashboard trouvé !</div>'
                    } else {
                        document.getElementById('notifications').innerHTML = htmlResponse
                    }
                }
            });
            setTimeout("read_notif();", 2000);
        }
        function mark_as_read_notif(notif) {
            var path = "php/include/notifications.php";
            $.ajax({
                type: "POST",
                url: path,
                data: 'read&notifid=' + notif
            });
        }
        read_notif();
    </script>
        <div id="notifications" class="col-md-3" style="bottom: 0px; right: 0px; position: fixed; z-index: 100000;"></div>
    <?php } ?>
</footer>
</body>
</html>
