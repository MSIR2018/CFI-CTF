

<style type="text/css">

    img {
        width: 170px;
        height: 170px;
        margin-left: auto;
        margin-right: auto;
    }

</style>





<!-- Page Content -->
<div class="container">

    <!-- Introduction Row -->
    <legend>À propos</legend>


        <div class="col-md-12">
            <h4 class="my-4">CTF - Capture The Flag</h4>
        </div>



        <div class="col-md-10 col-md-offset-1 col-sm-6 text-center mb-8">
<blockquote>
            <!--<p>Un CTF (capture the flag) est un concours de sécurité informatique. Il sera composé d'une multitude d'épreuves ayant chacune un nombre de points et une difficulté différente. Ces épreuves seront divisées en plusieurs catégories</p>-->

            <i class="fa fa-quote-left fa-2x" style="float: top;"></i>&nbsp&nbsp&nbsp&nbsp&nbspUn CTF (capture the flag) est un concours de sécurité informatique. Il sera composé d'une multitude d'épreuves ayant chacune un nombre de points et une difficulté différente. Ces épreuves seront divisées en plusieurs catégories &nbsp&nbsp&nbsp&nbsp&nbsp<i class="fa fa-quote-right fa-2x" style="float: right;" ></i>
</blockquote>

            <a href="https://cpirmob.fr/index.php?page=consult_breach" target="_blank" class="btn btn-info btn-sm" role="button" aria-pressed="true">Voir les catégories</a>

        </div>



        <div>

        </div>



        <div class="col-md-12">
            <h4>L'Équipe</h4>
        </div>
        <div class="col-md-4 col-sm-6 text-center">
            <img class="img-circle img-responsive" src="ressources/pic_team/gary.jpg" alt="">
            <h5><b>Gary Bernard</b></h5>

            <p>Détient un Master Bootstrap</p>
        </div>
        <div class="col-md-4 col-sm-6 text-center">
            <img class="img-circle img-responsive" src="ressources/pic_team/gwendal.jpg" alt="">
            <h5><b>Gwendal Orinel</b></h5>

            <p>Le couteau suisse</p>
        </div>
        <div class="col-md-4 col-sm-6 text-center">
            <img class="img-circle img-responsive" src="ressources/pic_team/mohamed.jpg" alt="">
            <h5><b>Mohamed Zenati</b></h5>

            <p>"Elle est bien garée ma voiture ?"</p>
        </div>




        <div class="col-md-2 col-sm-3 text-center">
        </div>



        <div class="col-md-4 col-sm-6 text-center">
            <img class="img-circle img-responsive" src="ressources/pic_team/romain.jpg" alt="">
            <h5><b>Romain Chevrier</b></h5>

            <p>"Putin ca me saoule ça !"</p>
        </div>
        <div class="col-md-4 col-sm-6 text-center">
            <img class="img-circle img-responsive" src="ressources/pic_team/alex.png" alt="">
            <h5><b>Alexandre Minaret</b></h5>

            <p>"L'ouverture de la pêche c'est bientôt les mecs !"</p>
        </div>


        <div class="col-md-2 col-sm-3 text-center mb-2">

        </div>



</div>
<!-- /.container -->


