<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['connected']=='yes')){ ?><div class="container"><?php
require("php/include/login_bdd.php");
if(isset($_POST['team_a_submit'])){
        $insertion = $connexion->prepare('UPDATE scenario SET scenario_team_a = :id_team_a WHERE id=:id');
        $insertion->execute(array(
            'id_team_a' => $_SESSION['id'],
            'id' => $_POST['id']
            ));
}
if(isset($_POST['team_b_submit'])){
        $insertion = $connexion->prepare('UPDATE scenario SET scenario_team_b = :id_team_b WHERE id=:id');
        $insertion->execute(array(
            'id_team_b' => $_SESSION['id'],
            'id' => $_POST['id']
        ));
}
    $reponse = $connexion->prepare('SELECT *,scenario.id as scenarioid,(SELECT DATE_ADD(start, INTERVAL scenario.scenario_time MINUTE) from game WHERE game.id_scenario=scenarioid and (game.id_team_a=:id_team or game.id_team_b=:id_team)) as enddate FROM scenario where scenario_deleted = 0');
    $reponse ->execute(array('id_team' => $_SESSION['id']));
    ?>
        <div class="row">
            <div class="col-md-12">
                <!-- Form Name -->
                <legend>Liste des scénarios</legend>
                <?php
				$nbscenario=0;
                while ($donnees = $reponse->fetch()){
                    ?>
                    <div class="panel-group" id="panel-<?php echo $donnees['scenarioid'];?>">
                        <div class="panel panel-default" >
                            <div class="panel-heading" style="height: 60px;">
                                <a class="panel-title pull-left" data-toggle="collapse" data-parent="#panel-<?php echo $donnees['scenarioid'];?>" href="#panel-element-<?php echo $donnees['scenarioid'];?>">Scénario : <?php echo $donnees['scenario_name'];?> <?php if($donnees['id_team_b']==$_SESSION['id']){ echo '<i style="color:red;">(Team Rouge)</i>'; }?><?php if($donnees['id_team_a']==$_SESSION['id']){ echo '<i style="color:blue;">(Team Bleue)</i>'; }?></a>
                                <h3 class="panel-title pull-right"><?php
                                    if($donnees['enddate'] != ''){
                                        //en jeu ou terminé
                                        $enddate = new DateTime($donnees['enddate']);
                                        $now = new DateTime('NOW');

                                        if($now < $enddate){
                                            //en jeu
                                            ?><a href="index.php?page=game&scenario=<?php echo $donnees['scenarioid']; ;?>"><button type="button" class="btn btn-primary">Acceder au Challenge</button></a><?php
                                        }else{
                                            //terminé
                                            ?><a href="index.php?page=game&scenario=<?php echo $donnees['scenarioid']; ;?>"><button type="button" class="btn btn-primary">Challenge terminé (Voir les résultats)</button></a><?php
                                        }
                                    }else{ //libre
                                        if(($donnees['scenario_team_a'] == '') or ($donnees['scenario_team_b'] == '')){
                                            //scenario libres
                                            if(($donnees['scenario_team_a']==$_SESSION['id']) or ($donnees['scenario_team_b']==$_SESSION['id'])){
                                                //attente equipe
                                                ?><button type="button" class="btn btn-info">En attente de l'équipe adverse</button><?php
                                            }else{
                                                ?><form action="index.php?page=list_challenge" method="post"><?php
                                                if($donnees['scenario_team_a'] == ''){
                                                    //scenario team a libre
                                                    ?><button id="team_a_submit" name="team_a_submit" type="submit" class="btn btn-primary">Blue Team</button><input name="id" type="hidden" value="<?php echo $donnees['scenarioid'];?>"/><?php
                                                }else{
                                                    //scenario team a occupé
                                                    ?><button id="team_a_submit" name="team_a_submit" type="submit" class="btn btn-primary" disabled>Blue Team</button><?php
                                                }
                                                if($donnees['scenario_team_b'] == ''){
                                                    //scenario team b libre
                                                    ?>&nbsp<button id="team_b_submit" name="team_b_submit" type="submit" class="btn btn-danger">Red Team</button><input name="id" type="hidden" value="<?php echo $donnees['scenarioid'];?>"/><?php
                                                }else{
                                                    //scenario team b occupé
                                                    ?>&nbsp<button id="team_b_submit" name="team_b_submit" type="submit" class="btn btn-danger" disabled>Red Team</button><?php
                                                }
                                                ?></form><?php
                                            }
                                        }else{
                                            if(($donnees['scenario_team_a'] == $_SESSION['id']) or ($donnees['scenario_team_b'] == $_SESSION['id'])) {
                                                //scenario prêt
                                                ?><a href="index.php?page=game&scenario=<?php echo $donnees['scenarioid']; ?>"><button type="button" class="btn btn-primary">Demarrer le Challenge</button></a><?php
                                            }else{
                                                //scenario occupé par d'autres équipes
                                                ?><button type="button" class="btn btn-warning">Scenario déja occupé par d'autres équipes</button><?php
                                            }

                                        }

                                    }
                                    ?>
                                </h3>
                            </div>
                            <div id="panel-element-<?php echo $donnees['scenarioid'];?>" class="panel-collapse collapse">
                                <div class="panel-body">

                                    <table class="table table-user-information">
                                        <tbody>
                                        <tr>
                                            <td>Nom du scénario : </td>
                                            <td><?php echo $donnees['scenario_name'];?></td>
                                        </tr>
                                        <tr>
                                            <td>Description du scénario </td>
                                            <td><?php echo $donnees['scenario_desc'];?></td>
                                        </tr>
                                        <tr>
                                            <td>Difficulté du scénario : </td>
                                            <td><?php echo $donnees['scenario_difficulty_average'];?></td>
                                        </tr>
                                        <tr>
                                            <td>Temps du scénario : </td>
                                            <td><?php echo $donnees['scenario_time'].' minutes';?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
					$nbscenario++;
                }
				if($nbscenario==0){ echo '<div class="alert alert-warning" role="alert">Aucun challenge disponible actuellement.. Soyez patients nos développeurs sont sur le coup !</div>'; };
                ?>
            </div>

        </div>
</form>
</div>
<?php  }else{
    echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
    echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
} ?>

