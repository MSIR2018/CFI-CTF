<div class="container"><?php
    require("php/include/login_bdd.php");
if(isset($_POST['team_submit'])){
$team_name = $_POST['team_name'];
$team_password = $_POST['team_password'];
$team_password2 = $_POST['team_password2'];
$team_member = $_POST['team_member'];
$team_desc = $_POST['team_desc'];
$team_logo = $_POST['team_logo'];

    if($_POST['action'] == "edit"){ //mode edit
        if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){
        $update = $connexion->prepare('UPDATE equipes SET team_name = :team_name, team_password = :team_password, team_member = :team_member, team_desc = :team_desc, team_logo = :team_logo WHERE id = :id ');
        $update->execute(array(
            'id' => $_POST['id'],
            'team_name' => $team_name,
            'team_password' => $team_password,
            'team_member' => $team_member,
            'team_desc' => $team_desc,
            'team_logo' => $team_logo));
        echo '<div class="alert alert-success text-center" role="alert">Equipe '.$team_name.' édité avec succès</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=list_team">';
        }else{
            echo '<div class="alert alert-danger text-center" role="alert">Merci de vous connecter !</div>';
            echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
        }
    }else {

        if ($team_password === $team_password2) {
            $insert = $connexion->prepare('INSERT INTO equipes ( team_name ,team_password, team_member,team_desc,team_logo,team_admin) VALUES (:team_name ,:team_password, :team_member,:team_desc,:team_logo,0) ');
            $insert->execute(array(
                'team_name' => $team_name,
                'team_password' => $team_password=md5($team_password),
                'team_member' => $team_member,
                'team_desc' => $team_desc,
                'team_logo' => $team_logo));
            echo '<div class="alert alert-success text-center" role="alert">Compte de l\'equipe crée avec succès</div>';
            echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
        } else {
            ?>
            <div class="container">
                <div class="col-md-8 col-md-offset-2">
                    <div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-triangle"></i> Les mots de
                        passes de correspondent pas. <a href="index.php?page=login" class="alert-link">
                            <button type="button" class="btn btn-danger pull-right" style="margin-top:-6px"><i
                                    class="fa fa-arrow-left"></i> Retour
                            </button>
                        </a></div>
                </div>
            </div>
            <?php
        }
    }
} else{
    if(isset($_GET['edit'])){ //mode edit
        if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){
        $edit = $connexion->query('SELECT * FROM equipes WHERE id='.$_GET['edit'].' ORDER BY id');
        foreach($edit as $equipe){
?>
    <div class="row">

        <form class="form-horizontal" action="index.php?page=add_team" method="post">
            <fieldset>

                <!-- Form Name -->
                <legend>Edition d'une Equipe</legend>

                <!-- Text input-->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="team_name">Nom de l'équipe</label>
                    <div class="col-md-4">
                        <input id="team_name" name="team_name" type="text" placeholder="Nom de l'équipe" value="<?php echo $equipe['team_name']; ?>" class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Password input-->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="team_password">Mot de passe</label>
                    <div class="col-md-3">
                        <input id="team_password" name="team_password" type="password" placeholder="Mot de passe" value="<?php echo $equipe['team_password']; ?>" class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Password input-->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="team_password2"></label>
                    <div class="col-md-3">
                        <input id="team_password2" name="team_password2" type="password" placeholder="Mot de passe" value="<?php echo $equipe['team_password']; ?>" class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="team_member">Membre de l'équipe</label>
                    <div class="col-md-5">
                        <input id="team_member" name="team_member" type="text" placeholder="Jhon Doe, Ashley James...." value="<?php echo $equipe['team_member']; ?>" class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Textarea -->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="team_desc">Description</label>
                    <div class="col-md-4">
                        <textarea class="form-control" id="team_desc"  name="team_desc" style="overflow: hidden"><?php echo $equipe['team_desc']; ?></textarea>
                    </div>
                </div>

                <!-- Multiple Checkboxes (inline) -->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="team_logo">Choix du logo</label>
                    <div class="col-md-8 ">
                    <table>
                        <tr>
                            <td style="padding-right: 20px">
                                <img src="ressources/logo_equipes/logo1.png" alt="" style="width: 50px">
                            </td>
                            <td style="padding-right: 20px">
                                <img src="ressources/logo_equipes/logo2.png" alt="" style="width: 50px">
                            </td>
                            <td style="padding-right: 20px">
                                <img src="ressources/logo_equipes/logo3.png" alt="" style="width: 50px">

                            </td>
                            <td>
                                <img src="ressources/logo_equipes/logo4.png" alt="" style="width: 50px">
                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <input type="radio"  name="team_logo" id="team_logo-0" value="1" <?php if($equipe['team_logo']=='1'){ echo 'checked="checked"'; }?>>
                            </td>
                            <td>
                                <input type="radio" name="team_logo" id="team_logo-1" value="2" <?php if($equipe['team_logo']=='2'){ echo 'checked="checked"'; }?>>
                            </td>
                            <td>
                                <input type="radio" name="team_logo" id="team_logo-2" value="3" <?php if($equipe['team_logo']=='3'){ echo 'checked="checked"'; }?>>
                            </td>
                            <td>
                                <input type="radio" name="team_logo" id="team_logo-3" value="4" <?php if($equipe['team_logo']=='4'){ echo 'checked="checked"'; }?>>
                            </td>
                        </tr>

                    </table>
                    </div>
                </div>

                <!-- Button -->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="team_submit"></label>
                    <div class="col-md-4">
                        <input type="hidden" name="action" id="action" value="edit" />
                        <input type="hidden" name="id" id="id" value="<?php echo $equipe['id']; ?>" />
                        <button id="team_submit" name="team_submit" type="submit" class="btn btn-success">Modification</button>
                    </div>
                </div>

            </fieldset>
        </form>
    </div>
        <?php }
    }else{
        echo '<div class="alert alert-danger text-center" role="alert">Merci de vous connecter !</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
    }
    }else{ ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="text-center">
                        <img alt="Bootstrap Image Preview" srcset="ressources/CapturTheFlag-Banner.png 2000w" class="img-rounded" />
                    </div>
                </div>
            </div>
            <div class="row">

                <form class="form-horizontal" action="index.php?page=add_team" method="post">
                    <div class="col-md-12">
                    <fieldset>

                        <!-- Form Name -->
                        <legend>Inscription Equipe</legend>

                        <!-- Text input-->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="team_name">Nom de l'équipe</label>
                            <div class="col-md-4">
                                <input id="team_name" name="team_name" type="text" placeholder="Nom de l'équipe" class="form-control input-md" required="">

                            </div>
                        </div>

                        <!-- Password input-->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="team_password">Mot de passe</label>
                            <div class="col-md-3">
                                <input id="team_password" name="team_password" type="password" placeholder="Mot de passe" class="form-control input-md" required="">

                            </div>
                        </div>

                        <!-- Password input-->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="team_password2"></label>
                            <div class="col-md-3">
                                <input id="team_password2" name="team_password2" type="password" placeholder="Mot de passe" class="form-control input-md" required="">

                            </div>
                        </div>

                        <!-- Text input-->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="team_member">Membre de l'équipe</label>
                            <div class="col-md-5">
                                <input id="team_member" name="team_member" type="text" placeholder="John Doe, Ashley James...." class="form-control input-md" required="">

                            </div>
                        </div>

                        <!-- Textarea -->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="team_desc">Description</label>
                            <div class="col-md-4">
                                <textarea class="form-control" id="team_desc" name="team_desc" style="overflow: hidden">Description de l'équipe...</textarea>
                            </div>
                        </div>

                        <!-- Multiple Checkboxes (inline) -->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="team_logo">Choix du logo</label>
                            <div class="col-md-8 ">
                                <table>
                                    <tr>
                                        <td style="padding-right: 20px">
                                            <img src="ressources/logo_equipes/logo1.png" alt="" style="width: 50px">
                                        </td>
                                        <td style="padding-right: 20px">
                                            <img src="ressources/logo_equipes/logo2.png" alt="" style="width: 50px">
                                        </td>
                                        <td style="padding-right: 20px">
                                            <img src="ressources/logo_equipes/logo3.png" alt="" style="width: 50px">

                                        </td>
                                        <td>
                                            <img src="ressources/logo_equipes/logo4.png" alt="" style="width: 50px">
                                        </td>
                                    </tr>
                                    <tr class="text-center">
                                        <td>
                                            <input type="radio" checked="checked" name="team_logo" id="team_logo-0" value="1">
                                        </td>
                                        <td>
                                            <input type="radio" name="team_logo" id="team_logo-1" value="2">
                                        </td>
                                        <td>
                                            <input type="radio" name="team_logo" id="team_logo-2" value="3">
                                        </td>
                                        <td>
                                            <input type="radio" name="team_logo" id="team_logo-3" value="4">
                                        </td>
                                    </tr>

                                </table>
                            </div>
                        </div>

                        <!-- Button -->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="team_submit"></label>
                            <div class="col-md-4">
                                <button id="team_submit" name="team_submit" type="submit" class="btn btn-success">Inscription</button>
                            </div>
                        </div>

                    </fieldset>
                        </div>
                </form>
            </div>
        <?php } }
    ?></div>