<?php
// On détruit notre session
session_destroy ();
// On redirige le visiteur vers la page d'accueil
echo "<script type = 'text/javascript'>document.location.replace('/index.php?page=accueil');</script>";
?>