<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){ ?><div class="container"><?php
require("php/include/login_bdd.php");

    function remove_apps($id){
        require("php/include/login_bdd.php");
        $reponse = $connexion->prepare('SELECT * FROM scenario WHERE id =:id');
        $reponse ->execute(array('id' => $id));

        while ($donnees = $reponse->fetch()) {
            $breachs = $connexion->query('SELECT * FROM breach');
            foreach ($breachs as $breach) {
                $findid = ';' . $breach['id'] . ';';
                if (strpos($donnees['breach_name'], $findid) !== false) {
                    $breach_name = $breach['breach_type'] . '-' . $breach['breach_template'];
                    shell_exec('sudo bash /var/www/html/pop-apps.sh remove ' . $breach_name . ' > /dev/null 2>/dev/null &');
                }
            }
        }
    }

if(isset($_POST['form'])){
    if($_POST['action'] == "delete"){ //mode delete
		remove_apps($_POST['id']);
        $delete = $connexion->prepare('UPDATE scenario SET scenario_deleted = 1 WHERE id = :id');
        $delete->execute(array(
            'id' => $_POST['id']));
    }
    if($_POST['action'] == "reset"){ //mode reset
		remove_apps($_POST['id']);
        $delete = $connexion->prepare('UPDATE scenario SET scenario_team_a = \'\' ,scenario_team_b = \'\' WHERE id = :id');
        $delete->execute(array(
            'id' => $_POST['id']));
    }
    if($_POST['action'] == "replay"){ //mode replay
		remove_apps($_POST['id']);
        $delete = $connexion->prepare('DELETE FROM game USING game LEFT JOIN scenario ON (scenario.id = game.id_scenario) WHERE id_scenario = :id and DATE_ADD(start, INTERVAL scenario.scenario_time MINUTE) > NOW()');
        $delete->execute(array(
            'id' => $_POST['id']));
    }
}
if(isset($_GET['delete']) or isset($_GET['reset']) or isset($_GET['replay'])){
    if(isset($_GET['delete'])){
    $scenarios = $connexion->query('SELECT * FROM scenario WHERE id='.$_GET['delete'].' ORDER BY id');
    foreach($scenarios as $scenario){
    ?>
        <form action="index.php?page=list_scenario" method="post">
            <input type="hidden" name="action" id="action" value="delete" />
            <input type="hidden" name="id" id="id" value="<?php echo $scenario['id']; ?>" />
            <legend style="text-align: left;">Supprimer le scénario</legend>

            <div class="alert alert-warning text-center">
                <div>
                    <p><strong>Warning:</strong> Etes vous sûr de vouloir supprimer <?php echo $scenario['scenario_name']; ?> ?
                        <a href="index.php?page=list_scenario" class="pull-right"><button name="form" style="margin-left:10px;" class="btn btn-danger" type="button" value="Non">Non</button></a>
                        <a class="pull-right"><button name="form" class="btn btn-success" style="margin-left:10px;" type="submit" value="Oui">Oui</button></a>
                    </p>


                </div>
            </div>
        </form>

    <?php } }
    if(isset($_GET['reset'])){
        $scenarios = $connexion->query('SELECT * FROM scenario WHERE id='.$_GET['reset'].' ORDER BY id');
        foreach($scenarios as $scenario){
            ?>
            <form action="index.php?page=list_scenario" method="post">
                <input type="hidden" name="action" id="action" value="reset" />
                <input type="hidden" name="id" id="id" value="<?php echo $scenario['id']; ?>" />
                <legend style="text-align: left;">Remettre à zero le scénario</legend>

                <div class="alert alert-warning text-center">
                    <div>
                        <p><strong>Warning:</strong> Etes vous sûr de vouloir remettre à zero le scénario "<?php echo $scenario['scenario_name']; ?>" ?
                            <a href="index.php?page=list_scenario" class="pull-right"><button name="form" style="margin-left:10px;" class="btn btn-danger" type="button" value="Non">Non</button></a>
                            <a class="pull-right"><button name="form" class="btn btn-success" style="margin-left:10px;" type="submit" value="Oui">Oui</button></a>
                        </p>


                    </div>
                </div>
            </form>

        <?php } }
    if(isset($_GET['replay'])){
        $scenarios = $connexion->query('SELECT * FROM scenario WHERE id='.$_GET['replay'].' ORDER BY id');
        foreach($scenarios as $scenario){
            ?>
            <form action="index.php?page=list_scenario" method="post">
                <input type="hidden" name="action" id="action" value="replay" />
                <input type="hidden" name="id" id="id" value="<?php echo $scenario['id']; ?>" />
                <legend style="text-align: left;">Rejouer le scénario</legend>

                <div class="alert alert-warning text-center">
                    <div>
                        <p><strong>Warning:</strong> Etes vous sûr de vouloir rejouer le scénario "<?php echo $scenario['scenario_name']; ?>" ?
                            <a href="index.php?page=list_scenario" class="pull-right"><button name="form" style="margin-left:10px;" class="btn btn-danger" type="button" value="Non">Non</button></a>
                            <a class="pull-right"><button name="form" class="btn btn-success" style="margin-left:10px;" type="submit" value="Oui">Oui</button></a>
                        </p>


                    </div>
                </div>
            </form>

        <?php } }
}else{
	if(isset($_GET['all'])){
		$reponse = $connexion->prepare('SELECT * FROM scenario ORDER BY id ASC');
		$reponse ->execute();
	}else{
		$reponse = $connexion->prepare('SELECT * FROM scenario where scenario_deleted = 0  ORDER BY id ASC');
		$reponse ->execute();
	}
    ?>

        <div class="row">
            <div class="col-md-12">
                <!-- Form Name -->
                <legend>Liste des scénarios <a onclick="window.location='index.php?page=list_scenario&all'"><button class="btn btn-xs pull-right btn-default" title="Voir les scénarios archivés"><i class="fa fa-eye-slash"></i></button></a></legend>
                <?php
                while ($donnees = $reponse->fetch()){
                    ?>
                    <div class="panel-group" id="panel-<?php echo $donnees['id'];?>">
                        <div class="panel panel-default">
                            <div class="panel-heading" style="height: 60px;">
                                <a class="panel-title pull-left" data-toggle="collapse" data-parent="#panel-<?php echo $donnees['id'];?>" href="#panel-element-<?php echo $donnees['id'];?>">Scénario : <?php echo $donnees['scenario_name'];?></a>
                                <h3 class="panel-title pull-right">
                                    <a title="Rejouer le scénario actuel" href="index.php?page=list_scenario&replay=<?php echo $donnees['id'];?>"><i class="fa fa-retweet" style="font-size:15px" ></i></a>&nbsp
                                    <a title="Remettre à zero pour une nouvelle partie" href="index.php?page=list_scenario&reset=<?php echo $donnees['id'];?>"><i class="fa fa-sync" style="font-size:15px" ></i></a>&nbsp
                                    <a title="Supprimer le scénario" href="index.php?page=list_scenario&delete=<?php echo $donnees['id'];?>"><i class="fa fa-trash" style="font-size:15px" ></i></a>&nbsp
                                    <a title="Éditer le scénario" href="index.php?page=add_scenario&edit=<?php echo $donnees['id'];?>"><i class="fa fa-cog" style="font-size:15px" ></i></a>
                                </h3>
                            </div>
                            <div id="panel-element-<?php echo $donnees['id'];?>" class="panel-collapse collapse">
                                <div class="panel-body">

                                    <table class="table table-user-information">
                                        <tbody>
                                        <tr>
                                            <td>Nom du scénario : </td>
                                            <td><?php echo $donnees['scenario_name'];?></td>
                                        </tr>
                                        <tr>
                                            <td>Description du scénario : </td>
                                            <td><?php echo $donnees['scenario_desc'];?></td>
                                        </tr>
                                        <tr>
                                            <td>Liste des failles : </td>
                                            <td><?php
                                                $breachs = $connexion->query('SELECT * FROM breach');
                                                foreach($breachs as $breach){ $findid=';'.$breach['id'].';';
                                                    if(strpos($donnees['breach_name'],$findid) !== false){ echo $breach['breach_type'].'-'.$breach['breach_template'].'</br>'; }
                                                }
                                                ?></td>
                                        </tr>
                                        <tr>
                                            <td>Temps du scénario : </td>
                                            <td><?php echo $donnees['scenario_time'];?> Minutes</td>
                                        </tr>
                                        <tr>
                                            <td>Difficulté du scénario : </td>
                                            <td><?php echo $donnees['scenario_difficulty_average'];?></td>
                                        </tr>
                                        <tr>
                                            <td>Equipe A (Bleu) inscrite : </td>
                                            <td><?php
                                                $equipes = $connexion->query('SELECT equipes.id,equipes.team_name FROM equipes,scenario WHERE scenario.scenario_team_a = equipes.id and scenario.id = '.$donnees['id'].' ');
                                                foreach($equipes as $equipe) {
                                                    echo '<a href="index.php?page=list_team#panel-'.$equipe['id'].'">'.$equipe['team_name'].'</a>';
                                                } ?></td>
                                        </tr>
                                        <tr>
                                            <td>Equipe B (Rouge) inscrite : </td>
                                            <td><?php
                                                $equipes = $connexion->query('SELECT equipes.id,equipes.team_name FROM equipes,scenario WHERE scenario.scenario_team_b = equipes.id and scenario.id = '.$donnees['id'].' ');
                                                foreach($equipes as $equipe) {
                                                    echo '<a href="index.php?page=list_team#panel-'.$equipe['id'].'">'.$equipe['team_name'].'</a>';
                                                } ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>

        </div>
    </div>
<?php }
}else{
    echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
    //echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
}
?>
