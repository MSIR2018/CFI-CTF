<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){ ?>
<div class="container">
    <?php
    $list = shell_exec('sudo bash /var/www/html/pop-apps.sh list');
    ?>
    <legend>Supervision de l'infrastructure (<span id="nbhost"></span>)</legend>
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>
                        Type
                    </th>
                    <th>
                        Nom du service
                    </th>
                    <th>
                        Equipe
                    </th>
                    <th>
                        Etat
                    </th>
                    <th>
                        Temps écoulé
                    </th>
                    <th>
                        Adresse IP
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php

                if($list!=''){
                $rows = explode("\n", $list);
                $i=0;
                foreach ($rows as $row) { $i++;
                    if($row!=''){
                    $data = explode(";", $row);
                    $name1=$data[0];
                        $name2=explode("_", $name1);
                            $name=$name2[0];
                            $name = substr($name,1);
                            $team=$name2[1];

                    if(strpos($name,'win') !== False){
                        $status='';
                        $status=$data[1];
                        if($status == 'shutoff'){ $status='exited'; }
                        $starttime='--';
                        $endtime='--';
                        $ip='';

                        if(strpos($name,'winxp') !== False){ if($team == 'a'){ $ip='11.0.0.250';} if($team == 'b'){ $ip='12.0.0.250';} }

                    }else{
                    $status=$data[1];
                    $startdate1 = explode(".", $data[2]);
                        $startdate2=new DateTime($startdate1[0]);
                        $now = new DateTime('NOW');
                        $starttime=$startdate2->diff($now);
                        $starttime=$starttime->format('%aJours %Hh:%Im:%Ss');

                    $enddate1 = explode(".", $data[3]);
                    $enddate2=new DateTime($enddate1[0]);
                    $now = new DateTime('NOW');
                    $endtime=$enddate2->diff($now);
                    $endtime=$endtime->format('%aJours %Hh:%Im:%Ss');


                    if($data[4]!='<no value>'){ $ip=$data[4]; }elseif($data[5]!='<no value>'){ $ip=$data[5]; }else{ $ip=''; }

                    }
                    ?>
                <tr>
                    <?php //rowspan="2" style="vertical-align:middle" ?>
                    <td class="tdlogo">
                        <?php if(strpos($name,'win') !== False){ ?><i class="fab fa-windows fa-2x"></i><?php }else{ ?><i class="fab fa-docker fa-2x"></i><?php } ?>
                    </td>
                    <td class="tdname">
                        <?php echo $name ?>
                    </td>
                    <td>
                        <?php if($team=='a'){ echo 'Bleu'; }elseif($team=='b'){ echo 'Rouge'; }else{ echo '--'; } ?>
                    </td>
                    <td>
                       <?php if($status == 'exited'){ ?><p class="text-danger" >Stopped</p><?php  }else{ ?><p class="text-success" >Running</p><?php } ?>
                    </td>
                    <td>
                        <?php if($status == 'exited'){ echo '<p class="text-danger" >'.$endtime; }else{ echo '<p class="text-success" >'.$starttime; } ?></p>
                    </td>
                    <td>
                        <a href="http://<?php echo $ip; ?>"><?php echo $ip; ?></a>
                    </td>
                </tr>
                <?php } } ?>
                    <script>
                        var nb = document.getElementsByClassName('tdname').length
                        var current = 1

                        document.getElementById('nbhost').innerHTML = nb;

                        while(current<nb){
                            if(document.getElementsByClassName('tdname')[current].innerHTML == document.getElementsByClassName('tdname')[current-1].innerHTML){
                                document.getElementsByClassName('tdname')[current-1].rowSpan = '2';
                                document.getElementsByClassName('tdlogo')[current-1].rowSpan = '2';
                                document.getElementsByClassName('tdname')[current-1].style.verticalAlign = 'middle';
                                document.getElementsByClassName('tdlogo')[current-1].style.verticalAlign = 'middle';
                                document.getElementsByClassName('tdname')[current].remove();
                                document.getElementsByClassName('tdlogo')[current].remove();
                            } current=current+1; }
                    </script>
                <?php } ?>
                </tbody>
            </table>
        </div>
</div>
<?php
}else{
    echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
    echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
}
?>