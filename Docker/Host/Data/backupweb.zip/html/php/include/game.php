<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['connected']=='yes')){ ?><div class="container"><?php

require("php/include/login_bdd.php");
if(isset($_POST['flagadd'])){
    $flag=$_POST['flag'];
    $id=$_POST['id'];
    $breachs = $connexion->prepare('SELECT breach.id,breach_flag_a,breach_flag_b,breach_points,scenario_team_a,scenario_team_b from scenario,breach where scenario.id = :id and scenario.breach_name LIKE CONCAT(\'%;\', CONCAT(breach.id),\';%\') ');
    $breachs ->execute(array('id' => $id));
    $flagok=0;

    foreach($breachs as $breach) {
        $findid='%;'.$breach['id'].';%';
        if(($breach['breach_flag_a']==$flag) and ($breach['scenario_team_a']==$_SESSION['id'])){ //si le flag est bon et l'equipe correspond au joueur
            $flagok=1;
            $update = $connexion->prepare('UPDATE game,scenario SET score_a = score_a + :score , game_flag_ok_a = CONCAT(game_flag_ok_a,CONCAT(\';\',CONCAT(:idbreach,\';\'))) WHERE id_scenario = :id and game_flag_ok_a NOT LIKE :findid and DATE_ADD(start, INTERVAL scenario.scenario_time MINUTE) > NOW()');
            $update->execute(array(
                'id' => $id,
                'findid' => $findid,
                'score' => $breach['breach_points'],
                'idbreach' => $breach['id']));
            echo '<div class="alert alert-success" role="alert">Flag trouvé avec succès</div>';
            echo '<META http-equiv="refresh" content="2; URL=index.php?page=game&scenario='.$id.'">';
        }
        if(($breach['breach_flag_b']==$flag) and ($breach['scenario_team_b']==$_SESSION['id'])){ //si le flag est bon et l'equipe correspond au joueur
            $flagok=1;
            $update = $connexion->prepare('UPDATE game,scenario SET score_b = score_b + :score , game_flag_ok_b = CONCAT(game_flag_ok_b,CONCAT(\';\',CONCAT(:idbreach,\';\'))) WHERE id_scenario = :id and game_flag_ok_b NOT LIKE :findid and DATE_ADD(start, INTERVAL scenario.scenario_time MINUTE) > NOW()');
            $update->execute(array(
                'id' => $id,
                'findid' => $findid,
                'score' => $breach['breach_points'],
                'idbreach' => $breach['id']));
            echo '<div class="alert alert-success" role="alert">Flag trouvé avec succès</div>';
            echo '<META http-equiv="refresh" content="2; URL=index.php?page=game&scenario='.$id.'">';
        }
    }
    if($flagok==0){
        echo '<div class="alert alert-warning" role="alert">Flag erroné, ce n\'est pas le bon cherche encore !</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=game&scenario='.$id.'">';
    }
}
if(isset($_GET['scenario'])){
    $reponse = $connexion->prepare('SELECT *,game.id as gameid FROM game,scenario WHERE game.id_scenario=scenario.id and scenario.id=:id and (game.id_team_a=:idteam or game.id_team_b=:idteam)');
    $reponse ->execute(array('id' => $_GET['scenario'],'idteam' => $_SESSION['id']));

    $breachs = $connexion->prepare('SELECT * FROM breach');
    $breachs ->execute();

    $totalpoints=0;
    $exist=0;
    while ($donnees = $reponse->fetch()){

        $nbbreach=substr_count($donnees['breach_name'],';')/2;
        $timeaverage=$nbbreach*15;


        if($donnees['gameid']!=''){ $exist=1; }

        $date=new DateTime($donnees['start']);
        $date->add(new DateInterval('PT' . $donnees['scenario_time'] . 'M'));
        $date->format('Y-m-d H:i');
        $now = new DateTime('NOW');

        $loadingtime=new DateTime($donnees['start']);
        $loadingtime->add(new DateInterval('PT' . $timeaverage . 'S'));

        $timebeforebegin = $now->diff($loadingtime);
        $wait=$timebeforebegin->format('%s');
        $timebeforebegin=$timebeforebegin->format('%i Minutes %s Secondes');

        if($loadingtime > $now) {
            echo '<div class="alert alert-info text-center" role="alert"><i class="fas fa-spinner fa-pulse"></i>  Creation de la partie en cours ( Environ '.$timebeforebegin.' )</div>';
            echo '<META http-equiv="refresh" content="'.$wait.'; URL=index.php?page=game&scenario='.$_GET['scenario'].'">';
        }else{
        ?>
            <div class="panel panel-primary">
                <div class="panel-heading" style="height: 40px;">
                    <div class="panel-title">
                        <div class="pull-left"><?php echo 'Scenario : '.$donnees['scenario_name']; ?></div>
                        <div class="pull-right"><?php
                            $date=new DateTime($donnees['start']);
                            $date->add(new DateInterval('PT' . $donnees['scenario_time'] . 'M'));
                            $date->format('Y-m-d H:i');
                            $now = new DateTime('NOW');
                            if($now < $date){
                                echo '<i id="countdown"></i> - En cours <i class="fa fa-circle-notch fa-spin"></i>';
                                ?>
                                <script type="text/javascript" src="assets/js/jquery.plugin.js"></script>
                                <script type="text/javascript" src="assets/js/jquery.countdown.js"></script>
                                <script>
                                    var countDownDate = new Date("<?php echo $date->format('Y-m-d H:i:s'); ?>").getTime();
                                    var x = setInterval(function() {
                                        var now = new Date().getTime();
                                        var distance = countDownDate - now;
                                        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                                        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                                        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                                        document.getElementById("countdown").innerHTML = days + "d " + hours + "h "
                                            + minutes + "m " + seconds + "s ";
                                        if (distance < 0) {
                                            clearInterval(x);
                                            document.getElementById("countdown").innerHTML = "EXPIRED";
                                        }
                                    }, 1000);
                                </script>
                                <?php
                            }else{
                                echo 'Terminé <i class="fa fa-check"></i>';
                            }
                            ?></div>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="table table-bordered">
                        <tr>
                            <th class="col-md-4"><?php echo 'Scenario : '.$donnees['scenario_name']; ?></br>
                                <?php if($_SESSION['id']==$donnees['id_team_b']){ echo 'Votre réseau : 11.0.0.0/8 </br>Réseau adverse : 12.0.0.0/8'; }; if($_SESSION['id']==$donnees['id_team_a']){ echo 'Votre réseau : 12.0.0.0/8 </br>Réseau adverse : 11.0.0.0/8'; } ?></th>
                            <th class="col-md-5"><?php echo 'Description : '.$donnees['scenario_desc']; ?></th>
                            <th><p class="pull-right"><?php echo 'Commencé à '.$donnees['start']; ?></p><p class="pull-right"><?php echo 'Fini à '.$date->format('Y-m-d H:i:s'); ?></p></th>
                        </tr>
                    </table>
                </div>
            </div>
        <?php if($now < $date) { //en cours ?>
            <div class="alert alert-info col-md-12" role="alert">
                <form action="index.php?page=game" method="post">
                    <div class="col-md-2"><span>Entrer un Flag :</span></div>
                    <div class="col-md-8"><input name="flag" type="text" class="form-control"></div>
                    <input type="hidden" name="id" value="<?php echo $donnees['id']; ?>">
                    <div class="col-md-2"><input type="submit" class="form-control btn btn-primary" name="flagadd" value="Valider"/></div>
                </form>
            </div>
            <table class="table table-striped">
                <tr>
                    <th>Nom de la faille</th><th>Description</th><th>Type</th><th>Difficulté</th><th>Points</th>
                </tr>
                <?php

                while ($breach = $breachs->fetch()){
                    $findid=';'.$breach['id'].';';
                    if((strpos($donnees['breach_name'],$findid) !== false) and ($donnees['id_team_a']==$_SESSION['id']) and (strpos($donnees['game_flag_ok_a'],$findid) !== false)){ ?>
                        <tr>
                            <td><?php echo $breach['breach_name']; ?></td>
                            <td><?php echo $breach['breach_desc']; ?></td>
                            <td><?php echo $breach['breach_type']; ?></td>
                            <td><?php echo $breach['breach_difficulty']; ?></td>
                            <td><?php echo $breach['breach_points']; ?></td>
                        </tr>
                        <?php $totalpoints=$totalpoints+$breach['breach_points']; ?>
                    <?php }
                    if((strpos($donnees['breach_name'],$findid) !== false) and ($donnees['id_team_b']==$_SESSION['id']) and (strpos($donnees['game_flag_ok_b'],$findid) !== false)){ ?>
                        <tr>
                            <td><?php echo $breach['breach_name']; ?></td>
                            <td><?php echo $breach['breach_desc']; ?></td>
                            <td><?php echo $breach['breach_type']; ?></td>
                            <td><?php echo $breach['breach_difficulty']; ?></td>
                            <td><?php echo $breach['breach_points']; ?></td>
                        </tr>
                        <?php $totalpoints=$totalpoints+$breach['breach_points']; ?>
                    <?php }
                }
                ?>
                <tr>
                    <td colspan="4" style="text-align: right;" >Total points</td><td><?php echo $totalpoints; ?></td>
                </tr>
            </table>
        <?php }else{ //terminé ?>
            <table class="table table-striped">
                <tr>
                    <th>Nom de la faille</th><th>Description</th><th>Type</th><th>Difficulté</th><th>Points</th><th>Resolue ?</th>
                </tr>
                <?php while ($breach = $breachs->fetch()){
                    $findid=';'.$breach['id'].';';
                    if(strpos($donnees['breach_name'],$findid) !== false){ ?>
                        <tr>
                            <td><?php echo $breach['breach_name']; ?></td>
                            <td><?php echo $breach['breach_desc']; ?></td>
                            <td><?php echo $breach['breach_type']; ?></td>
                            <td><?php echo $breach['breach_difficulty']; ?></td>
                            <td><?php echo $breach['breach_points']; ?></td>
                            <td><?php
                                if($_SESSION['id']==$donnees['id_team_a']){ if(strpos($donnees['game_flag_ok_a'],$findid) !== false) { echo 'Oui'; $totalpoints=$totalpoints+$breach['breach_points']; }else{ echo 'Non'; } }
                                if($_SESSION['id']==$donnees['id_team_b']){ if(strpos($donnees['game_flag_ok_b'],$findid) !== false) { echo 'Oui'; $totalpoints=$totalpoints+$breach['breach_points']; }else{ echo 'Non'; } }
                                ?></td>
                        </tr>
                    <?php }} ?>
                <tr>
                    <td colspan="4" style="text-align: right;" >Total points</td><td><?php echo $totalpoints; ?></td>
                </tr>
            </table>
        <?php } ?>
    <?php } }
    if($exist == 0){ //si la game n'existe pas on verifie les infos et on la crée
        $check = $connexion->prepare('SELECT * FROM scenario WHERE scenario.id = :id and scenario_team_a != \'\' and scenario_team_b != \'\'');
        $check ->execute(array('id' => $_GET['scenario']));

        $creable=0;
        while ($game = $check->fetch()){
            if(!empty($game['id'])){
                $creable=1;
                $insert = $connexion->prepare('INSERT INTO game ( id_scenario ,id_team_a, id_team_b,score_a,score_b) VALUES (:id_scenario ,:id_team_a, :id_team_b,0,0) ');
                $insert->execute(array(
                    'id_scenario' => $_GET['scenario'],
                    'id_team_a' => $game['scenario_team_a'],
                    'id_team_b' => $game['scenario_team_b']));
                $breachlist='';
                foreach($breachs as $breach){ $findid=';'.$breach['id'].';';
                    if(strpos($game['breach_name'],$findid) !== false){
                        $breach_name=$breach['breach_type'].'-'.$breach['breach_template'];
                        shell_exec('sudo bash /var/www/html/pop-apps.sh create '.$breach_name.' > /dev/null 2>/dev/null &');
                    }
                }
                echo '<div class="text-center"><i class="fas fa-spinner fa-pulse"></i></div>';
                echo '<META http-equiv="refresh" content="0; URL=index.php?page=game&scenario='.$_GET['scenario'].'">';
            }
        }
        if($creable==0){
            echo '<div class="alert alert-danger" role="alert">Cette Partie n\'est pas prête ou n\'existe pas</div>';
        }
    };
} ?></div><?php
    }else{
        echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
    }
    ?>


