<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['connected']=='yes')){ ?>
<?php
require("php/include/login_bdd.php");
$reponse = $connexion->prepare('SELECT *,(SELECT team_name from equipes WHERE id = id_team_a) as team_a, (SELECT team_name from equipes WHERE id = id_team_b) as team_b FROM game, scenario WHERE game.id_scenario = scenario.id');
$reponse ->execute();
$leader = $connexion->prepare('SELECT *,equipes.id as idequipe, IFNULL((SELECT sum(score_a) from game where id_team_a=idequipe),0) as scorea,IFNULL((SELECT sum(score_b) from game where id_team_b=idequipe),0) as scoreb FROM equipes ORDER BY scorea+scoreb DESC ');
$leader ->execute();
?>
<div class="container">
        <div class="col-md-12">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#leaderboard">Leaderboard</a></li>
                <li><a data-toggle="tab" href="#history">Historique des parties</a></li>
            </ul>
            <div class="tab-content">
                <div id="leaderboard" class="tab-pane fade in active">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>
                                Place
                            </th>
                            <th>
                                Equipe
                            </th>
                            <th>
                                Score
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 0;
                        while ($donnees = $leader->fetch()) {
                            $i++;
                            ?>
                            <tr <?php
                            if ($i==1){
                                echo 'class="success"';
                            }
                            if ($i==2){
                                echo 'class="warning"';
                            }
                            if ($i==3){
                                echo 'class="info"';
                            }
                            if ($i>3){
                                echo 'class="active"';
                            }
                            ?>>
                                <td>
                                    <?php echo $i; ?>
                                </td>
                                <td>
                                    <?php echo $donnees['team_name']; ?>
                                </td>
                                <td>
                                    <?php echo $donnees['scorea'] + $donnees['scoreb']; ?>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
                <div id="history" class="tab-pane fade">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>
                                Scénario
                            </th>
                            <th>
                                Equipe Bleu
                            </th>
                            <th>
                                Equipe Rouge
                            </th>
                            <th>
                                Score Bleu
                            </th>
                            <th>
                                Score Rouge
                            </th>
                            <th>
                                Terminé en (min)
                            </th>
                            <th>
                                Vainqueur
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        while ($donnees = $reponse->fetch()){?>


                        <tr>
                            <td>
                                <?php echo $donnees['scenario_name']; ?>
                            </td>
                            <td>
                                <?php echo $donnees['team_a']; ?>
                            </td>
                            <td>
                                <?php echo $donnees['team_b']; ?>
                            </td>
                            <td>
                                <?php echo $donnees['score_a']; ?>
                            </td>
                            <td>
                                <?php echo $donnees['score_b']; ?>
                            </td>
                            <td>
                                <?php echo $donnees['scenario_time']; ?>
                            </td>
                            <td>
                                <?php
                                if ($donnees['score_a']<$donnees['score_b']){
                                    echo 'Equipe '.$donnees['team_b'];
                                }
                                if ($donnees['score_b']<$donnees['score_a']){
                                    echo 'Equipe '.$donnees['team_a'];
                                }
                                if ($donnees['score_b']==$donnees['score_a']){
                                    echo 'Egalité';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

</div><?php
}else{
    echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
    echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
}
?>