<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){ ?><div class="container"><?php
require("php/include/login_bdd.php");
if(isset($_POST['add_breach'])){

    if($_POST['action'] == "edit"){ //mode edit
        $update = $connexion->prepare('UPDATE breach SET breach_name = :breach_name, breach_type = :breach_type, breach_difficulty = :breach_difficulty, breach_points = :breach_points, breach_desc = :breach_desc, breach_template = :breach_template,breach_flag_a = :breach_flag_a,breach_flag_b = :breach_flag_b WHERE id = :id ');
        $update->execute(array(
            'id' => $_POST['id'],
            'breach_name' => $_POST['breach_name'],
            'breach_type' => $_POST['breach_type'],
            'breach_difficulty' => $_POST['breach_difficulty'],
            'breach_points' => $_POST['breach_points'],
            'breach_desc' => $_POST['breach_desc'],
            'breach_flag_a' => $_POST['breach_flag_a'],
            'breach_flag_b' => $_POST['breach_flag_b'],
            'breach_template' => $_POST['breach_template']));
        echo '<div class="alert alert-success text-center" role="alert">Faille '.$_POST['breach_name'].' éditée avec succès</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=list_breach">';
    }else {
        $insert = $connexion->prepare('INSERT INTO breach ( breach_name ,breach_type, breach_difficulty,breach_points,breach_desc,breach_template,breach_flag_a,breach_flag_b) VALUES (:breach_name ,:breach_type, :breach_difficulty,:breach_points,:breach_desc,:breach_template,:breach_flag_a,:breach_flag_b) ');
        $insert->execute(array(
            'breach_name' => $_POST['breach_name'],
            'breach_type' => $_POST['breach_type'],
            'breach_difficulty' => $_POST['breach_difficulty'],
            'breach_points' => $_POST['breach_points'],
            'breach_template' => $_POST['breach_template'],
            'breach_flag_a' => $_POST['breach_flag_a'],
            'breach_flag_b' => $_POST['breach_flag_b'],
            'breach_desc' => $_POST['breach_desc']));
        echo '<div class="alert alert-success text-center" role="alert">Faille ' . $_POST['breach_name'] . ' crée avec succès</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=list_breach">';
    }
}else{
$reponse = $connexion->prepare('SELECT AUTO_INCREMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = \'CTF\' AND TABLE_NAME = \'breach\';');
$reponse ->execute();
$id=$reponse->fetch();



if(isset($_GET['edit'])){ //mode edit

    $edit = $connexion->query('SELECT * FROM breach WHERE id='.$_GET['edit'].' ORDER BY id');
    foreach($edit as $breach){

    ?>
        <form class="form-horizontal" action="index.php?page=add_breach" method="post">
            <fieldset>

                <!-- Form Name -->
                <legend>Edition d'une faille</legend>

                <div class="col-md-6">
                    <!-- Text input-->
                    <div class="form-group">
                        <label class="col-md-6 control-label" for="breach_name">Nom de la faille</label>
                        <div class="col-md-6">
                            <input id="breach_name" name="breach_name" type="text" placeholder="Faille"
                                   class="form-control input-md" required="" value="<?php echo $breach['breach_name']; ?>">

                        </div>
                    </div>

                    <!-- Text input-->

                    <div class="form-group">
                        <label class="col-md-6 control-label" for="breach_type">Type de la faille</label>
                        <div class="col-md-6">
                            <select class="form-control" id="breach_type" name="breach_type" required="" onchange="changename(this.value);">
                                <optgroup label="Container Docker">
                                    <option value="http" <?php if($breach['breach_type']=='http'){ echo 'selected'; }?>>http</option>
                                    <option value="ssh" <?php if($breach['breach_type']=='ssh'){ echo 'selected'; }?>>SSH</option>
                                    <option value="net" <?php if($breach['breach_type']=='net'){ echo 'selected'; }?>>Réseaux</option>
                                    <option value="system" <?php if($breach['breach_type']=='system'){ echo 'selected'; }?>>Système</option>
                                    <option value="cryptographie" <?php if($breach['breach_type']=='cryptographie'){ echo 'selected'; }?>>Cryptographie</option>
                                    <option value="ftp" <?php if($breach['breach_type']=='ftp'){ echo 'selected'; }?>>FTP</option>
                                    <option value="cryptanalyse" <?php if($breach['breach_type']=='cryptanalyse'){ echo 'selected'; }?>>Cryptanalyse</option>
                                    <option value="cracking" <?php if($breach['breach_type']=='cracking'){ echo 'selected'; }?>>Cracking</option>
                                </optgroup>
                                <optgroup label="Machine Virtuelle">
                                    <option value="winxp" <?php if($breach['breach_type']=='winxp'){ echo 'selected'; }?>>Windows XP</option>
                                </optgroup>
                            </select>
                        </div>
                    </div>

                    <!-- Multiple Radios (inline) -->
                    <div class="form-group">
                        <label class="col-md-6 control-label" for="breach_difficulty">Niveau de difficulté</label>
                        <div class="col-md-6">
                            <label class="radio-inline" for="breach_difficulty-0">
                                <input type="radio" name="breach_difficulty" id="breach_difficulty-0" value="1" <?php if($breach['breach_difficulty']=='1'){ echo 'checked="checked"'; }?>>
                                1
                            </label>
                            <label class="radio-inline" for="breach_difficulty-1">
                                <input type="radio" name="breach_difficulty" id="breach_difficulty-1" value="2" <?php if($breach['breach_difficulty']=='2'){ echo 'checked="checked"'; }?>>
                                2
                            </label>
                            <label class="radio-inline" for="breach_difficulty-2">
                                <input type="radio" name="breach_difficulty" id="breach_difficulty-2" value="3" <?php if($breach['breach_difficulty']=='3'){ echo 'checked="checked"'; }?>>
                                3
                            </label>
                            <label class="radio-inline" for="breach_difficulty-3">
                                <input type="radio" name="breach_difficulty" id="breach_difficulty-3" value="4" <?php if($breach['breach_difficulty']=='4'){ echo 'checked="checked"'; }?>>
                                4
                            </label>
                            <label class="radio-inline" for="breach_difficulty-4">
                                <input type="radio" name="breach_difficulty" id="breach_difficulty-4" value="5" <?php if($breach['breach_difficulty']=='5'){ echo 'checked="checked"'; }?>>
                                5
                            </label>
                        </div>
                    </div>

                    <!-- Appended Input-->
                    <div class="form-group">
                        <label class="col-md-6 control-label" for="breach_points">Nombre de points</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input id="breach_points" name="breach_points" class="form-control" placeholder="1-50"
                                       type="number" min="0" max="50" required="" value="<?php echo $breach['breach_points']; ?>">
                                <span class="input-group-addon">points</span>
                            </div>

                        </div>
                    </div>
                    <!-- Textarea -->
                    <div class="form-group">
                        <label class="col-md-6 control-label" for="breach_desc">Description de la faille</label>
                        <div class="col-md-6">
                            <textarea class="form-control" id="breach_desc" name="breach_desc"><?php echo $breach['breach_desc']; ?></textarea>
                        </div>
                    </div>

                    <!-- Text input-->
                    <div class="form-group">
                        <label class="col-md-6 control-label" for="breach_template">ID du template</label>
                        <div class="col-md-6">
                            <input id="breach_template" readonly name="breach_template" type="text" value="<?php echo $breach['breach_template']; ?>"  class="text-muted form-control input-md"/>

                        </div>
                    </div>

                    <!-- Button -->
                    <div class="form-group">
                        <label class="col-md-6 control-label" for="submit"></label>
                        <div class="col-md-6">
                            <input type="hidden" name="action" id="action" value="edit" />
                            <input type="hidden" name="id" id="id" value="<?php echo $breach['id']; ?>" />
                            <button id="add_breach" name="add_breach" type="submit" class="btn btn-success">Enregistrer</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="panel panel-default ">
                        <div class="panel-heading">
                            <h3 class="panel-title"><center>Import des fichiers</center></h3>
                        </div>
                        <ul class="list-group">
                            <li class="list-group-item"><p>Glissez - Déposez les deux dossiers TeamA et TeamB dans le GIT sous la forme:
                                    <br> <b id="filename1"></b>/TeamA/FICHIERS <br> <b id="filename2"></b>/TeamB/FICHIERS </p></li>

                            <li class="list-group-item">
                                <script>
                                    function popup(nom_de_la_page, nom_de_la_fenetre)
                                    {
                                        window.open (nom_de_la_page, nom_de_la_fenetre, config='height=700,width=1050,toolbar=no, menubar=no, scrollbars=yes,resizable=no,location=no,directories=no,status=no')
                                    }
                                </script>
                                <center><A href="javascript:popup('https://github.com/MSIR2018/CFI-CTF/upload/master/Docker/Challenges','Import fichiers Equipes');"><button class="btn btn-primary" type="button">Importer les fichiers</button></A></center></li>
                        </ul>
                    </div>
                    <div class="form-group">
                        <label class="col-md-4 control-label" for="breach_flag_a">Flag de l'équipe A</label>
                        <div class="col-md-6">
                            <input id="breach_flag_a" name="breach_flag_a" type="text" placeholder="MOT DE PASSE"
                                   class="form-control input-md" required="" value="<?php echo $breach['breach_flag_a']; ?>">

                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-4 control-label" for="breach_flag_b">Flag de l'équipe B</label>
                        <div class="col-md-6">
                            <input id="breach_flag_b" name="breach_flag_b" type="text" placeholder="MOT DE PASSE"
                                   class="form-control input-md" required="" value="<?php echo $breach['breach_flag_b']; ?>">

                        </div>
                    </div>
                </div>
                <script>
                    function changename(name){
                        document.getElementById('filename1').innerHTML = name+'-<?php echo $breach['breach_template']; ?>';
                        document.getElementById('filename2').innerHTML = name+'-<?php echo $breach['breach_template']; ?>';
                    }
                    changename(document.getElementById('breach_type').value);
                </script>
            </fieldset>
        </form>
<?php } }else{ ?>
    <form class="form-horizontal" action="index.php?page=add_breach" method="post">
        <fieldset>

            <!-- Form Name -->
            <legend>Création d'une faille</legend>

            <div class="col-md-6">
                <!-- Text input-->
                <div class="form-group">
                    <label class="col-md-6 control-label" for="breach_name">Nom de la faille</label>
                    <div class="col-md-6">
                        <input id="breach_name" name="breach_name" type="text" placeholder="Faille"
                               class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Text input-->

                <div class="form-group">
                    <label class="col-md-6 control-label" for="breach_type">Type de la faille</label>
                    <div class="col-md-6">
                        <select class="form-control" id="breach_type" name="breach_type" required="" onchange="changename(this.value);">
                            <optgroup label="Container Docker">
                                <option value="http">HTTP</option>
                                <option value="ssh">SSH</option>
                                <option value="net">Réseaux</option>
                                <option value="system">Système</option>
                                <option value="cryptographie">Cryptographie</option>
                                <option value="ftp">FTP</option>
                                <option value="cryptanalyse">Cryptanalyse</option>
                                <option value="cracking">Cracking</option>
                            </optgroup>
                            <optgroup label="Machine Virtuelle">
                                <option value="winxp">Windows XP</option>
                            </optgroup>
                        </select>
                    </div>
                </div>

                <!-- Multiple Radios (inline) -->
                <div class="form-group">
                    <label class="col-md-6 control-label" for="breach_difficulty">Niveau de difficulté</label>
                    <div class="col-md-6">
                        <label class="radio-inline" for="breach_difficulty-0">
                            <input type="radio" name="breach_difficulty" id="breach_difficulty-0" value="1"
                                   checked="checked">
                            1
                        </label>
                        <label class="radio-inline" for="breach_difficulty-1">
                            <input type="radio" name="breach_difficulty" id="breach_difficulty-1" value="2">
                            2
                        </label>
                        <label class="radio-inline" for="breach_difficulty-2">
                            <input type="radio" name="breach_difficulty" id="breach_difficulty-2" value="3">
                            3
                        </label>
                        <label class="radio-inline" for="breach_difficulty-3">
                            <input type="radio" name="breach_difficulty" id="breach_difficulty-3" value="4">
                            4
                        </label>
                        <label class="radio-inline" for="breach_difficulty-4">
                            <input type="radio" name="breach_difficulty" id="breach_difficulty-4" value="5">
                            5
                        </label>
                    </div>
                </div>

                <!-- Appended Input-->
                <div class="form-group">
                    <label class="col-md-6 control-label" for="breach_points">Nombre de points</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            <input id="breach_points" name="breach_points" class="form-control" placeholder="1-50"
                                   type="number" min="0" max="50" required="">
                            <span class="input-group-addon">points</span>
                        </div>

                    </div>
                </div>
                <!-- Textarea -->
                <div class="form-group">
                    <label class="col-md-6 control-label" for="breach_desc">Description de la faille</label>
                    <div class="col-md-6">
                        <textarea class="form-control" id="breach_desc" name="breach_desc" placeholder="Description"></textarea>
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group">
                    <label class="col-md-6 control-label" for="breach_template">ID du template</label>
                    <div class="col-md-6">
                        <input id="breach_template" readonly name="breach_template" type="text" value="<?php echo sprintf("%03d", $id["AUTO_INCREMENT"]);?>"  class="text-muted form-control input-md"/>

                    </div>
                </div>

                <!-- Button -->
                <div class="form-group">
                    <label class="col-md-6 control-label" for="submit"></label>
                    <div class="col-md-6">
                        <button id="add_breach" name="add_breach" type="submit" class="btn btn-success">Enregistrer</button>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-default ">
                    <div class="panel-heading">
                        <h3 class="panel-title"><center>Import des fichiers</center></h3>
                    </div>
                    <ul class="list-group">
                        <li class="list-group-item"><p>Glissez - Déposez les deux dossiers TeamA et TeamB dans le GIT sous la forme:
                                <br> <b id="filename1"></b>/TeamA/FICHIERS <br><b id="filename2"></b>/TeamB/FICHIERS </p></li>

                        <li class="list-group-item">
                            <script>
                                function popup(nom_de_la_page, nom_de_la_fenetre)
                                {
                                    window.open (nom_de_la_page, nom_de_la_fenetre, config='height=700,width=1050,toolbar=no, menubar=no, scrollbars=yes,resizable=no,location=no,directories=no,status=no')
                                }
                            </script>
                            <center><A href="javascript:popup('https://github.com/MSIR2018/CFI-CTF/upload/master/Docker/Challenges','Import fichiers Equipes');"><button class="btn btn-primary" type="button">Importer les fichiers</button></A></center></li>
                    </ul>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label" for="breach_flag_a">Flag de l'équipe A</label>
                    <div class="col-md-6">
                        <input id="breach_flag_a" name="breach_flag_a" type="text" placeholder="MOT DE PASSE"
                               class="form-control input-md" required="">

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label" for="breach_flag_b">Flag de l'équipe B</label>
                    <div class="col-md-6">
                        <input id="breach_flag_b" name="breach_flag_b" type="text" placeholder="MOT DE PASSE"
                               class="form-control input-md" required="">

                    </div>
                </div>
            </div>
            <script>
                function changename(name){
                    document.getElementById('filename1').innerHTML = name+'-<?php echo sprintf("%03d", $id["AUTO_INCREMENT"]);?>';
                    document.getElementById('filename2').innerHTML = name+'-<?php echo sprintf("%03d", $id["AUTO_INCREMENT"]);?>';
                }
                changename(document.getElementById('breach_type').value);
            </script>

        </fieldset>
    </form>
<?php }  } ?></div><?php
    }else{
        echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
    }
    ?>

