<?php session_start();
if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){
if(!isset($_GET['scenario'])){
    ?>
    <style xmlns="http://www.w3.org/1999/html">
        .container-fluid {
            padding-right: 15px !important;
            padding-left: 15px !important;
            margin-right: 0px !important;
            margin-left: 0px !important;
        }

        /* Style the input field */
        #myInput {
            /*padding: 20px;*/
            margin-top: -6px;
            border: 0;
            border-radius: 0;
            /*color: #000;*/
            background: #f1f1f1;
        }

        .badge-ok {
            display: inline-block;
            min-width: 10px;
            padding: 3px 7px;
            font-size: 12px;
            font-weight: 700;
            line-height: 1;
            color: #fff;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            background-color: #6AC259;
            border-radius: 10px;
        }

        .badge-nok {
            display: inline-block;
            min-width: 10px;
            padding: 3px 7px;
            font-size: 12px;
            font-weight: 700;
            line-height: 1;
            color: #fff;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            background-color: #D75A4A;
            border-radius: 10px;
        }

        .list-group-item > .badge-ok {
            float: right;
        }

        .list-group-item > .badge-nok {
            float: right;
        }

        .grad_red_blue {
            color: #FFFFFF !important;
            background: linear-gradient(to right, #579995, #579995, #999894, #ce1616, #ce1616) !important;
            border-color: #579995 !important;
        }
        .container-full {
            padding: 10px;
            background-color:#fff;
            border-radius:10px;
            opacity:0.95;
        }
	/*	a,a:link,a:visited,a:active,a:hover {
			text-decoration: none;
			color: #fff
		} */

    </style>
    <script language="JavaScript">
        function team_a(idscenario) {
            var path = "php/include/game_monitor.php";
            $.ajax({
                type: "GET",
                url: path,
                data: 'scenario=' + idscenario + '&team=a',
                success: function (htmlResponse) {
                    if (htmlResponse == '') {
                        document.getElementById('divteamA').innerHTML = '<div class=\"alert alert-info\">Aucune dashboard trouvé !</div>'
                    } else {
                        document.getElementById('divteamA').innerHTML = htmlResponse
                    }
                }
            });
            setTimeout("team_a(currentscenario);", 2000);
        }
        function team_b(idscenario) {
            var path = "php/include/game_monitor.php";
            $.ajax({
                type: "GET",
                url: path,
                data: 'scenario=' + idscenario + '&team=b',
                success: function (htmlResponse) {
                    if (htmlResponse == '') {
                        document.getElementById('divteamB').innerHTML = '<div class=\"alert alert-info\">Aucune dashboard trouvé !</div>'
                    } else {
                        document.getElementById('divteamB').innerHTML = htmlResponse
                    }
                }
            });
            setTimeout("team_b(currentscenario);", 2000);
        }
        function infoscenario(idscenario) {
            document.getElementById('divmenu').classList.remove("col-md-offset-5","container-full");
            document.getElementById('divmenutitle').style.color='#fff';
            var path = "php/include/game_monitor.php";
            currentscenario = document.getElementById('currentscenario').value = idscenario;
            $.ajax({
                type: "GET",
                url: path,
                data: 'scenario=' + idscenario + '&info',
                success: function (htmlResponse) {
                    if (htmlResponse == '') {
                        document.getElementById('infoscenario').innerHTML = '<div class=\"alert alert-info\">Aucune dashboard trouvé !</div>'
                    } else {
                        document.getElementById('infoscenario').innerHTML = htmlResponse
                    }
                }
            });
            setTimeout("infoscenario(currentscenario);", 1000);
        }
    </script>
    <?php   }
    if((isset($_GET['scenario'])) and ((isset($_GET['team'])) or (isset($_GET['info'])))){

        require("login_bdd.php");

        $reponse = $connexion->prepare('SELECT start,scenario.breach_name,game.game_flag_ok_a,game.game_flag_ok_b,scenario_time,scenario_name, game.id as gameid,(SELECT team_name from equipes WHERE id=scenario.scenario_team_a) as teama,(SELECT team_logo from equipes WHERE id=scenario.scenario_team_a) as teamalogo,(SELECT team_name from equipes WHERE id=scenario.scenario_team_b) as teamb,(SELECT team_logo from equipes WHERE id=scenario.scenario_team_b) as teamblogo FROM game,scenario WHERE game.id_scenario=scenario.id and scenario.id=:id');
        $reponse ->execute(array('id' => $_GET['scenario']));

        $breachs = $connexion->prepare('SELECT * FROM breach');
        $breachs ->execute(array('id' => $_GET['scenario'],'idteam' => $_SESSION['id']));

        $totalpointsA=0;
        $totalpointsB=0;
        $nbbreachokA=0;
        $nbbreachokB=0;
        $totalnbbreachA=0;
        $totalnbbreachB=0;
        if($_GET['team']=='a'){
            while ($donnees = $reponse->fetch()){  ?>
                <div class="col-md-5 container-full">
                    <h3 class="text-center">
                        Equipe Bleu : <?php echo $donnees['teama'];?>
                        <br><br>
                        <img alt="Logo Equipe Bleu" src="ressources/logo_equipes/logo<?php echo $donnees['teamalogo'];?>.png" class="img-thumbnail" />
                    </h3>
                    <br>
                    <br>
                    <div class="list-group">
                        <a href="#" class="list-group-item blue-team">Failles</a>
                        <?php while ($breach = $breachs->fetch()){ $findid=';'.$breach['id'].';';
                            if(strpos($donnees['breach_name'],$findid) !== false){ $totalnbbreachA++;
                                ?><li class="list-group-item"><?php echo $breach['breach_type'].'-'.$breach['breach_template']; if(strpos($donnees['game_flag_ok_a'],$findid) !== false) { $totalpointsA=$totalpointsA+$breach['breach_points']; $nbbreachokA++;?><span class="badge-ok"><i class="fa fa-check"></i></span><?php }else{ ?><span class="badge-nok"><i class="fa fa-times"></i></span><?php } ?></li>
                            <?php }} ?>
                        <li style="margin-top: 20px" class="list-group-item">Total:<span class="badge pull-right"><?php echo $nbbreachokA.'/'.$totalnbbreachA.' Réussie'; ?></span></li>
                    </div>
                    <div class="progress progress-striped active">
                        <?php $percent=(($nbbreachokA-$totalnbbreachA)/$totalnbbreachA*100)+100; ?>
                        <div class="progress-bar progress-bar-primary blue-team" role="progressbar" aria-valuenow="<?php echo $percent; ?>"
                             aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percent; ?>%">
                            <?php echo round($percent); ?>% Complete
                        </div>
                    </div>
                    <button type="button" class="btn btn-block blue-team"><?php echo $totalpointsA; ?> Points </button>
                </div>
            <?php }
        }
        if($_GET['team']=='b'){
            while ($donnees = $reponse->fetch()){ ?>
                <div class="col-md-5 container-full">
                    <h3 class="text-center">
                        Equipe Rouge : <?php echo $donnees['teamb'];?>
                        <br><br>
                        <img alt="Logo Equipe Rouge" src="ressources/logo_equipes/logo<?php echo $donnees['teamblogo'];?>.png" class="img-thumbnail" />
                    </h3>
                    <br>
                    <br>
                    <div class="list-group">
                        <a href="#" class="list-group-item red-team">Failles</a>
                        <?php while ($breach = $breachs->fetch()){  $findid=';'.$breach['id'].';';
                            if(strpos($donnees['breach_name'],$findid) !== false){ $totalnbbreachB++;
                                ?><li class="list-group-item"><?php echo $breach['breach_type'].'-'.$breach['breach_template']; if(strpos($donnees['game_flag_ok_b'],$findid) !== false) { $totalpointsB=$totalpointsB+$breach['breach_points']; $nbbreachokB++; ?><span class="badge-ok"><i class="fa fa-check"></i></span><?php }else{ ?><span class="badge-nok"><i class="fa fa-times"></i></span><?php } ?></li>
                            <?php }} ?>
                        <li style="margin-top: 20px" class="list-group-item">Total:<span class="badge pull-right"><?php echo $nbbreachokB.'/'.$totalnbbreachB.' Réussie'; ?></span></li>
                    </div>
                    <div class="progress progress-striped active">
                        <?php $percent=(($nbbreachokB-$totalnbbreachB)/$totalnbbreachB*100)+100; ?>
                        <div class="progress-bar progress-bar-danger red-team" role="progressbar" aria-valuenow="<?php echo $percent; ?>"
                             aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percent; ?>%">
                            <?php echo round($percent); ?>% Complete
                        </div>
                    </div>
                    <button type="button" class="btn btn-block red-team"><?php echo $totalpointsB; ?> Points</button>
                </div>
            <?php }
        }
        if(isset($_GET['info'])){
            while ($donnees = $reponse->fetch()){
                $startdate=new DateTime($donnees['start']);
                $startdate->format('Y-m-d H:i:s');
                $end=new DateTime($donnees['start']);
                $end->add(new DateInterval('PT' . $donnees['scenario_time'] . 'M'));
                $end->format('Y-m-d H:i:s');
                $now = new DateTime('NOW');
                $now->format('Y-m-d H:i:s');
                $status='';
                $interval = $now->diff($end);

                $timer = $interval->format('%Hh%Im:%Ss');

                if($now < $end){ $status='En cours'; $timer = $interval->format('%Hh%Im:%Ss'); }else{ $status='Terminé'; $timer = 'Expiré'; } ?>
                <li class="list-group-item"><b><?php echo $donnees['scenario_name'];?></b></li>
                <li class="list-group-item">Etat du scénario : <?php echo $status;?></li>
                <li class="list-group-item">Temps restant : <?php echo $timer; ?></li>
        <?php } } ?>

    <?php } ?>

    <?php if(!isset($_GET['scenario'])){ ?>
        <div class="col-md-12" >
        <div id="divteamA"></div>
        <div class="col-md-2 col-md-offset-5 container-full" id="divmenu">
            <h3 class="text-center" style="color:#000;" id="divmenutitle">
                Monitoring des CTF
            </h3>
            <div class="text-center">
                <div class="dropdown">
                    <button class="btn grad_red_blue dropdown-toggle" type="button" data-toggle="dropdown">Sélection scénario
                        <span class="caret"></span></button>  <a onclick="window.location='index.php?page=game_monitor&all'"><button class="btn" title="Voir les scénarios archivés"><i class="fa fa-eye-slash"></i></button></a>
                    <ul class="dropdown-menu" style="margin-left:20px">
                        <input class="form-control" id="myInput" type="text" placeholder="Recherche..">
                        <?php
						if(isset($_GET['all'])){
							$scenarios = $connexion->prepare('SELECT scenario.id,scenario.scenario_name FROM scenario,game WHERE scenario.id=game.id_scenario');
							$scenarios ->execute();
						}else{
							$scenarios = $connexion->prepare('SELECT scenario.id,scenario.scenario_name FROM scenario,game WHERE scenario.id=game.id_scenario and scenario.scenario_deleted = 0');
							$scenarios ->execute();
						}
                        while ($scenario = $scenarios->fetch()){ ?>
                        <li><a href="#" onclick="infoscenario('<?php echo $scenario['id'];?>')"><?php echo $scenario['scenario_name'];?></a></li>
                        <?php } ?>
                    </ul>
                </div>
                <br>
                <br>
                <ul class="list-group">
                    <div id="infoscenario"></div>
                </ul>
            </div>
        </div>
        <div id="divteamB"></div>
        </div>
        <input type="hidden" id="currentscenario" value="">
<script>
    team_a(currentscenario);
    team_b(currentscenario);
    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $(".dropdown-menu li").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
</script>
<?php } }else{
echo '<div class="alert alert-danger text-center" role="alert">Merci de vous connecter !</div>';
echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
}
?>