<?php if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['team_admin']==1) and ($_SESSION['connected']=='yes')){ ?><div class="container"><?php

    require("php/include/login_bdd.php");
if(isset($_POST['scenario_submit'])){
    $scenario_name = $_POST['scenario_name'];
    $scenario_desc = $_POST['scenario_desc'];
    $breach_selected = $_POST['breach_name'];
    $scenario_time = $_POST['scenario_time'];

    $average=0;
    $listbreach='';
    $nb=0;
    foreach($breach_selected as $breach) { //calcul des breach
        $breach=explode("*", $breach);
        $average=$average+$breach[1];
        $listbreach=';'.$breach[0].';'.$listbreach;
        $nb++;
    }
    $average=$average/$nb;

    if($_POST['action'] == "edit"){ //mode edit
        $update = $connexion->prepare('UPDATE scenario SET scenario_name = :scenario_name, scenario_desc = :scenario_desc, breach_name = :breach_name, scenario_difficulty_average = :scenario_difficulty_average, scenario_time = :scenario_time WHERE id = :id ');
        $update->execute(array(
            'id' => $_POST['id'],
            'scenario_name' => $scenario_name,
            'scenario_desc' => $scenario_desc,
            'breach_name' => $listbreach,
            'scenario_difficulty_average' => $average,
            'scenario_time' => $scenario_time));
        echo '<div class="alert alert-success text-center" role="alert">Scénario '.$scenario_name.' édité avec succès</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=list_scenario">';
    }else {
        $insert = $connexion->prepare('INSERT INTO scenario ( scenario_name ,scenario_desc, breach_name,scenario_time,scenario_difficulty_average) VALUES (:scenario_name ,:scenario_desc, :breach_name,:scenario_time,:scenario_difficulty_average) ');
        $insert->execute(array(
            'scenario_name' => $scenario_name,
            'scenario_desc' => $scenario_desc,
            'breach_name' => $listbreach,
            'scenario_difficulty_average' => $average,
            'scenario_time' => $scenario_time));
        echo '<div class="alert alert-success text-center" role="alert">Scénario '.$scenario_name.' crée avec succès</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=list_scenario">';
    }
} else {

    $reponse = $connexion->prepare('SELECT * FROM breach ORDER BY id ASC');
    $reponse ->execute();

    if(isset($_GET['edit'])){ //mode edit

        $edit = $connexion->query('SELECT * FROM scenario WHERE id='.$_GET['edit'].' ORDER BY id');
        foreach($edit as $scenario){
    ?>
        <form class="form-horizontal" action="index.php?page=add_scenario" method="post">
            <fieldset>

                <!-- Form Name -->
                <legend>Edition d'un scénario</legend>

                <!-- Text input-->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="scenario_name">Nom du scénario</label>
                    <div class="col-md-4">
                        <input id="scenario_name" name="scenario_name" type="text" placeholder="Scénario"
                               class="form-control input-md" required="" value="<?php echo $scenario['scenario_name']; ?>">

                    </div>
                </div>

                <!-- Textarea -->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="scenario_desc">Description du scénario</label>
                    <div class="col-md-4">
                        <textarea class="form-control" id="scenario_desc" name="scenario_desc"><?php echo $scenario['scenario_desc']; ?></textarea>
                    </div>
                </div>

                <!-- Multiple Checkboxes -->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="breach_name">Failles</label>
                    <div class="col-md-4">
                        <?php while ($donnees = $reponse->fetch()){ $findid=';'.$donnees['id'].';'; ?>
                        <div class="checkbox">
                            <label for="breach_name-<?php echo $donnees['id'];?>">
                                <input type="checkbox" name="breach_name[]" id="breach_name-<?php echo $donnees['id'];?>" value="<?php echo $donnees['id'].'*'.$donnees['breach_difficulty'];?>" <?php if(strpos($scenario['breach_name'],$findid) !== false){ echo 'checked="checked"'; }?>>
                                <?php echo $donnees['breach_name'].' ('.$donnees['breach_type'].'-'.$donnees['breach_template'].')';?>
                            </label>
                        </div>
                        <?php } ?>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="scenario_time">Durée du scénario (minutes)</label>
                    <div class="col-md-2">
                        <select id="scenario_time" name="scenario_time" class="form-control">
                            <option value="30" <?php if($scenario['scenario_time']=='30'){ echo 'selected'; }?>>30 minutes</option>
                            <option value="60" <?php if($scenario['scenario_time']=='60'){ echo 'selected'; }?>>60 minutes</option>
                            <option value="90" <?php if($scenario['scenario_time']=='90'){ echo 'selected'; }?>>90 minutes</option>
                            <option value="120" <?php if($scenario['scenario_time']=='120'){ echo 'selected'; }?>>120 minutes</option>
                            <option value="150" <?php if($scenario['scenario_time']=='150'){ echo 'selected'; }?>>150 minutes</option>
                            <option value="180" <?php if($scenario['scenario_time']=='180'){ echo 'selected'; }?>>180 minutes</option>
                            <option value="210" <?php if($scenario['scenario_time']=='210'){ echo 'selected'; }?>>210 minutes</option>
                            <option value="240" <?php if($scenario['scenario_time']=='240'){ echo 'selected'; }?>>240 minutes</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-4 control-label" for="submit"></label>
                    <div class="col-md-4">
                        <input type="hidden" name="action" id="action" value="edit" />
                        <input type="hidden" name="id" id="id" value="<?php echo $scenario['id']; ?>" />
                        <button id="submit" name="scenario_submit" type="submit" class="btn btn-success">Enregistrer</button>
                    </div>
                </div>

            </fieldset>
        </form>

        <?php } }else{ ?>
            <form class="form-horizontal" action="index.php?page=add_scenario" method="post">
                <fieldset>

                    <!-- Form Name -->
                    <legend>Création d'un scénario</legend>

                    <!-- Text input-->
                    <div class="form-group">
                        <label class="col-md-4 control-label" for="scenario_name">Nom du scénario</label>
                        <div class="col-md-4">
                            <input id="scenario_name" name="scenario_name" type="text" placeholder="Scénario"
                                   class="form-control input-md" required="">

                        </div>
                    </div>

                    <!-- Textarea -->
                    <div class="form-group">
                        <label class="col-md-4 control-label" for="scenario_desc">Description du scénario</label>
                        <div class="col-md-4">
                            <textarea class="form-control" id="scenario_desc" name="scenario_desc">Description pour les joueurs</textarea>
                        </div>
                    </div>

                    <!-- Multiple Checkboxes -->
                    <div class="form-group">
                        <label class="col-md-4 control-label" for="breach_name">Failles</label>
                        <div class="col-md-4">
                            <?php while ($donnees = $reponse->fetch()){ ?>
                                <div class="checkbox">
                                    <label for="breach_name-<?php echo $donnees['id'];?>">
                                        <input type="checkbox" name="breach_name[]" id="breach_name-<?php echo $donnees['id'];?>" value="<?php echo $donnees['id'].'*'.$donnees['breach_difficulty'];?>">
                                        <?php echo $donnees['breach_name'].' ('.$donnees['breach_type'].'-'.$donnees['breach_template'].')';?>
                                    </label>
                                </div>
                            <?php } ?>
                        </div>
                    </div>

                    <!-- Select Basic -->
                    <div class="form-group">
                        <label class="col-md-4 control-label" for="scenario_time">Durée du scénario (minutes)</label>
                        <div class="col-md-2">
                            <select id="scenario_time" name="scenario_time" class="form-control">
                                <option value="30">30 minutes</option>
                                <option value="60">60 minutes</option>
                                <option value="90">90 minutes</option>
                                <option value="120">120 minutes</option>
                                <option value="150">150 minutes</option>
                                <option value="180">180 minutes</option>
                                <option value="210">210 minutes</option>
                                <option value="240">240 minutes</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-4 control-label" for="submit"></label>
                        <div class="col-md-4">
                            <button id="submit" name="scenario_submit" type="submit" class="btn btn-success">Enregistrer</button>
                        </div>
                    </div>

                </fieldset>
            </form>
    <?php } } ?></div><?php
    }else{
        echo '<div class="alert alert-danger text-center container container-transparent" role="alert">Merci de vous connecter !</div>';
        echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
    }
    ?></div>