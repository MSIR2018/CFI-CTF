<?php
$connexion=new PDO("mysql:host=localhost;dbname=CTF","root","Azerty78");
$connexion -> exec("SET CHARACTER SET utf8");
?>