<nav class="navbar-wrapper navbar-default navbar-static-top">

	<div class="container-fluid">
		<div class="navbar-header">
			<button class="navbar-toggle" data-target="#myNavbar" data-toggle="collapse" type="button"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span></button>
			<a class="navbar-brand" href="index.php?page=accueil">CTF - CFI</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="active">
					<a href="index.php?page=accueil">Accueil <i class="fas fa-home"></i></a>
				</li>
				 <?php
				if(isset($_SESSION['team_name']) AND isset($_SESSION['team_admin']) AND ($_SESSION['team_admin'] == 1)){
						?>
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#">Gestion du CTF <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li class="dropdown-header">Breach sector <i class="fa fa-bug"></i></li>
						<li><a href="index.php?page=add_breach"><i class="fa fa-plus"></i> Ajouter une faille</a></li>
						<li><a href="index.php?page=list_breach"><i class="fa fa-list"></i> Liste des failles</a></li>
						<li class="dropdown-header">Scenario sector <i class="fa fa-book"></i></li>
						<li><a href="index.php?page=add_scenario"><i class="fa fa-plus"></i> Ajouter un scénario</a></li>
						<li><a href="index.php?page=list_scenario"><i class="fa fa-list"></i> Liste des scénarios</a></li>
						<li class="dropdown-header">Team sector <i class="fa fa-users"></i></li>
						<li><a href="index.php?page=add_team"><i class="fa fa-plus"></i> Ajouter une équipe</a></li>
						<li><a href="index.php?page=list_team"><i class="fa fa-list"></i> Liste des équipes</a></li>
						<li class="dropdown-header">Notifications sector <i class="fa fa-bell"></i></li>
						<li><a href="index.php?page=notification"><i class="fa fa-genderless"></i> Envoyer une notification</a></li>
					</ul>
				</li>
						<?php
						}
						?>
				<?php
				if(isset($_SESSION['team_name']) AND isset($_SESSION['team_admin']) AND ($_SESSION['team_admin'] == 1)){
					?>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Monitoring <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li class="dropdown-header">Game sector <i class="fa fa-gamepad"></i></li>
							<li><a href="index.php?page=game_monitor"><i class="fa fa-binoculars"></i> Suivie des parties</a></li>
							<li><a href="index.php?page=monitor_infra"><i class="fa fa-server"></i> Supervision infra</a></li>
						</ul>
					</li>
					<?php
				}
				?>
				<?php
				if(isset($_SESSION['team_name'])){
						?>
					<li><a href="index.php?page=leaderboard">Tableau des scores <i class="fa fa-list-ol"></i></a></li>
				 <?php
						}
						?>
					<li><a href="index.php?page=consult_breach">Liste des failles <i class="fa fa-list-alt"></i></a></li>
					<li><a href="index.php?page=whatis_ctf">CTF C'est quoi <i class="fa fa-question"></i></a></li>
				<?php
				if(isset($_SESSION['team_name'])){
				?>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Challenge <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li class="dropdown-header">Challenge sector <i class="fa fa-trophy"></i></li>
							<li><a href="index.php?page=list_challenge"><i class="fa fa-flag"></i> Liste des scénarios</a></li>
						</ul>
					</li>
					<?php
				}
				?>
			</ul>
			<ul class="nav navbar-nav navbar-right">
						<?php
				 if(isset($_SESSION['team_name'])){
						?>
					<li><a href="index.php?page=accueil"><i class="fas fa-user"></i> Bonjour <?php echo $_SESSION['team_name']; ?></a></li>
					<li><a href="index.php?page=logout"><i class="fas fa-sign-out-alt"></i> Se déconnecter</a></li>
						<?php
							}else{
						?>
				<li><a href="index.php?page=add_team"><i class="fas fa-user"></i> S'inscrire</a></li>
				<li><a href="index.php?page=accueil"><i class="fas fa-sign-out-alt"></i> Se connecter</a></li>

					<?php
					}
					?>
			</ul>
		</div>
	</div>

</nav>