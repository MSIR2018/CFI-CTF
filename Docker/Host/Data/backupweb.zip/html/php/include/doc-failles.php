<?php
require("login_bdd.php");
$reponse = $connexion->prepare('SELECT * FROM breach ORDER BY breach_type ASC');
$reponse ->execute();
?>
    <div class="row">
        <div class="col-md-12">
            <?php while ($donnees = $reponse->fetch()){ ?>

                                
                                   
                                    <tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Nom de la faille : </span>
                                        <span style="font-size: 14,1px"><?php echo $donnees['breach_type'];?>-<?php echo $donnees['breach_template'];?></span></br>
                                    </tr>
									<tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Categorie de la faille : </span>
                                        <span style="font-size: 14,1px"><?php echo $donnees['breach_type'];?></span></br>
                                    </tr>
									<tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Objectif de la faille : </span>
                                        <span style="font-size: 14,1px"><?php echo $donnees['breach_name'];?></span></br>
                                    </tr>
                                    <tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Difficulté de la faille : </span>
                                        <span style="font-size: 14,1px"><?php echo $donnees['breach_difficulty'];?></span></br>
                                    </tr>
                                    <tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Description de la faille : </span>
                                        <span style="font-size: 14,1px"><?php echo $donnees['breach_desc'];?></span></br>
                                    </tr>
									<tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Capture d'ecran : </span>
                                        <span style="font-size: 14,1px"></span></br>
                                    </tr>
									<tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Solution : </span>
                                        <span style="font-size: 14,1px"></span></br>
                                    </tr>
                                    <tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Flag de la faille A : </span>
                                        <span style="font-size: 14,1px"><?php echo $donnees['breach_flag_a'];?></span></br>
                                    </tr>
                                    <tr>
                                        <span style="font-size: 17px; color: rgb(79,129,189);">Flag de la faille B : </span>
                                        <span style="font-size: 14,1px"><?php echo $donnees['breach_flag_b'];?></span></br>
                                    </tr>
                                   
								<br>
                         </div>
    </div>
                <?php
            }
            ?>