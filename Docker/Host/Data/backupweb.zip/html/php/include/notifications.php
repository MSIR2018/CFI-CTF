<?php
session_start();
if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['connected']=='yes')) {

    require("login_bdd.php");

    if(isset($_POST['read'])){

        if(isset($_POST['notifid'])){
            $update = $connexion->prepare('UPDATE notification SET notif_is_read = 1 WHERE (notif_id_team = :idteam or notif_id_team = 0)and id=:notifid');
            $update->execute(array(
                'notifid' => $_POST['notifid'],
                'idteam' => $_SESSION['id']));
        }

        $notifs = $connexion->prepare('SELECT * FROM notification WHERE (notif_id_team=:idteam or notif_id_team = 0) and notif_is_read=0');
        $notifs->execute(array('idteam' => $_SESSION['id']));

        while ($notif = $notifs->fetch()){  ?>
            <div class="alert alert-<?php echo $notif['notif_type']; ?> text-center alert-dismissible" role="alert" style="margin-bottom: 5px; margin-right: 0px">
                <button type="button" class="close" onclick="mark_as_read_notif('<?php echo $notif['id']; ?>');" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <?php echo $notif['notif_message']; ?>
            </div>

<?php } }else{
        if($_SESSION['team_admin']==1){
        if(isset($_POST['add'])) {
            $insert = $connexion->prepare('INSERT INTO notification ( notif_id_team ,notif_type, notif_message) VALUES (:notif_id_team ,:notif_type, :notif_message) ');
            $insert->execute(array(
                'notif_id_team' => $_POST['destinataire'],
                'notif_type' => $_POST['type'],
                'notif_message' => $_POST['message']));
            echo '<div class="alert alert-success text-center" role="alert">Message envoyé avec succès</div>';
            echo '<META http-equiv="refresh" content="2; URL=index.php?page=notification">';
        }else{

            $teams = $connexion->prepare('SELECT * FROM equipes');
            $teams->execute(array('idteam' => $_SESSION['id']));

            ?>
            <div class="container">
                <legend>Envoi de notifications</legend>
                <form action="index.php?page=notification" method="post">
                    <div class="col-md-12">
                        <div class="form-group col-md-12" >
                            <label class="col-md-3 control-label" for="destinataire">Destinataire :</label>
                            <div class="col-md-6">
                                <select class="form-control" id="destinataire" name="destinataire" required="">
                                    <option value="0">Tout le monde</option>
                                    <?php while ($team = $teams->fetch()){  ?>
                                    <option value="<?php echo $team['id']; ?>"><?php echo $team['team_name']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-12" >
                            <label class="col-md-3 control-label" for="type">Type de Notification</label>
                            <div class="col-md-9">
                                <label class="radio-inline" for="type-success">
                                    <input type="radio" name="type" id="type-success" value="success" checked="checked">
                                    Success (Vert)
                                </label>
                                <label class="radio-inline" for="type-danger">
                                    <input type="radio" name="type" id="type-danger" value="danger">
                                    Danger (Rouge)
                                </label>
                                <label class="radio-inline" for="type-warning">
                                    <input type="radio" name="type" id="type-warning" value="warning">
                                    Warning (Orange)
                                </label>
                                <label class="radio-inline" for="type-info">
                                    <input type="radio" name="type" id="type-info" value="info">
                                    Info (Bleu clair)
                                </label>
                            </div>
                        </div>
                        <div class="form-group col-md-12" >
                            <label class="col-md-3 control-label" for="message">Message :</label>
                            <div class="col-md-6">
                              <textarea class="form-control" id="message" name="message" maxlength="255" required=""></textarea>
                            </div>
                        </div>
                        <div class="form-group col-xs-12 col-md-offset-4 col-md-4" >
                            <input type="submit" name="add" value="Valider" class="form-control btn btn-primary">
                        </div>
                    </div>
                </form>
            </div>
        <?php }}else{
            echo '<div class="alert alert-danger text-center" role="alert">Vous n\'avez pas les droits necessaires</div>';
            echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
        }
    }
} ?>