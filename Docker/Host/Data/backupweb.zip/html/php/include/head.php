<head>    
  <title>Capture The Flag - CFI</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" type="image/png" href="ressources/favicon-32x32.png" sizes="32x32" />
		<link rel="icon" type="image/png" href="ressources/favicon-16x16.png" sizes="16x16" />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="assets/css/Footer-with-button-logo.css">
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script defer src="assets/js/all.js"></script>


<style type="text/css">
body {
	background: #bcdee7 url("ressources/background_fade.jpg") no-repeat center center fixed;
    background-color: transparent;
}
.myForm {
  min-width: 500px;
  position: absolute;
  text-align: center;
  top: 20%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 2.5rem
}
@media (max-width: 500px) {
  .myForm {
    min-width: 90%;
  }
}
/* !important */
.container{
	padding: 10px ;
	background-color:#fff;
	border-radius:10px;
	opacity:0.95;
}
.container-transparent{
	background-color:transparent;
}
<?php
$date = date("Y-m-d");
$heure = date("H:i");
?>
/*Marge de 60px et un background en dégradé*/

/*Debut css pour flèche ancre top*/
a#cRetour {
	border-radius: 3px;
	padding: 10px;
	font-size: 15px;
	text-align: center;
	color: #fff;
	background: rgba(0,0,0,0.25);
	position: fixed;
	right: 20px;
	opacity: 1;
	z-index: 99999;
	transition: all ease-in .2s;
	backface-visibility: hidden;
	-webkit-backface-visibility: hidden;
	text-decoration: none;
}

a#cRetour:before {
	content: "\25b2";
}

a#cRetour:hover {
	background: rgba(0,0,0,1);
	transition: all ease-in .2s;
}

a#cRetour.cInvisible {
	bottom: -35px;
	opacity: 0;
	transition: all ease-in .5s;
}

a#cRetour.cVisible {
	bottom: 20px;
	opacity: 1;
}
/*Fin css pour flèche ancre top*/


.carousel-control.left {
	background-image: none;
}
.carousel-control.right {
	background-image: none;
}
 .blue-team {
	 background-color: #579995 !important;
	 border-color: #579995 !important;
	 color: #fff !important;
 }
.red-team {
	background-color: #ce1616 !important;
	border-color: #ce1616 !important;
	color: #fff !important;
}
</style>
<script>    
  $(document).ready(function() {
  	var docHeight = $(window).height();
  	var footerHeight = $('#footer').height();
  	var footerTop = $('#footer').position().top + footerHeight;
  	if (footerTop < docHeight) {
  		$('#footer').css('margin-top', 0 + (docHeight - footerTop) + 'px');
  	}
  });        
 </script>
</head>