<?php
if(isset($_SESSION['team_name']) and isset($_SESSION['connected']) and ($_SESSION['connected']=='yes')){

        $reponse = $connexion->prepare('SELECT * FROM scenario,game WHERE scenario.id=game.id_scenario and DATE_ADD(start, INTERVAL scenario.scenario_time MINUTE) < NOW() and (id_team_a=:idteam or id_team_b=:idteam);');
        $reponse ->execute(array('idteam' => $_SESSION['id']));

    ?>
    <div class="container">
        <div>
            <legend>Profil de l'équipe</legend>
            <div class="col-xs-6 col-xs-offset-3 col-sm-offset-0 col-sm-2 col-md-2 col-lg-2 toppad">
                <div class="panel panel-info">
                    <div class="panel-body">
                        <div style="margin-left: auto; margin-right: auto;"> <img alt="User Pic" src="ressources/logo_equipes/logo<?php echo $_SESSION['team_logo'] ?>.png" class="img-circle img-responsive" style="width: 100%; "> </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 toppad" >
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title"><?php echo $_SESSION['team_name'] ?></h3>
                    </div>
                    <div class="panel-body" style="padding: 0px;">
                        <div class="row">
                            <div class=" col-md-12 col-lg-12 ">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <td>Nom de l'équipe:</td>
                                        <td><?php echo $_SESSION['team_name'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>Membre de l'équipe</td>
                                        <td><?php echo $_SESSION['team_member'];?></td>
                                    </tr>
                                    <tr>
                                        <td>Description de l'équipe</td>
                                        <td><?php echo $_SESSION['team_desc'];?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br><br>
    <div class="container">
            <div class="panel-group">
                <div class="panel panel-info">
                    <div class="panel-heading" style="height: 60px;">
                        <h3 class="panel-title pull-left" style="margin-top: 10px">Historique des scénarios</h3>
                        <br>
                    </div>
                    <div class="panel-body" style="padding: 0px;">
					<?php $nbscenario=0; ?>
                        <table class="table table-striped">
                            <tr>
                                <th>
                                    Nom du scénario :
                                </th>
                                <th>
                                    Score obtenu :
                                </th>
                                <th>
                                    Score de l'equipe adverse :
                                </th>
                                <th>
                                    Joué le :
                                </th>
                            </tr>
                            <?php while ($donnees = $reponse->fetch()){ ?>
                            <tr>
                                <td><?php echo $donnees['scenario_name'];?></td>
                                <td><?php if($donnees['id_team_a'] == $_SESSION['id']){ echo $donnees['score_a']; }else{ echo $donnees['score_b']; } ?></td>
                                <td><?php if($donnees['id_team_a'] != $_SESSION['id']){ echo $donnees['score_a']; }else{ echo $donnees['score_b']; } ?></td>
                                <td><?php echo $donnees['start'];?></td>
                            </tr>
							<?php  $nbscenario++; } 
							if($nbscenario==0){ echo '<div class="alert alert-warning" style="margin-bottom: 0px" role="alert">Aucun challenge terminé.. Tentez votre chance en jouant un de nos scénarios !</div>'; } ?>
							</table>
                    </div>
                </div>
            </div>
        </div>

<?php }else{
    echo '<div class="alert alert-danger text-center" role="alert">Merci de vous connecter !</div>';
    echo '<META http-equiv="refresh" content="2; URL=index.php?page=accueil">';
}
?></div>