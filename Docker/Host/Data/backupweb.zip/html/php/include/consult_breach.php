<style xmlns="http://www.w3.org/1999/html">


    html {
        font-family: Lato, 'Helvetica Neue', Arial, Helvetica, sans-serif;
        font-size: 14px;
    }

    h5 {
        font-size: 1.28571429em;
        font-weight: 700;
        line-height: 1.2857em;
        margin: 0;
    }

    .card {
        font-size: 1em;
        overflow: hidden;
        padding: 0;
        border: none;
        border-radius: .28571429rem;
        box-shadow: 0 1px 3px 0 #d4d4d5, 0 0 0 1px #d4d4d5;
    }

    .card-block {
        font-size: 1em;
        position: relative;
        margin: 0;
        padding: 1em;
        border: none;
        border-top: 1px solid rgba(34, 36, 38, .1);
        box-shadow: none;
    }

    .card-img-top {
        display: block;
        width: 150px;
        height: auto;
    }

    .card-title {
        font-size: 1.28571429em;
        font-weight: 700;
        line-height: 1.2857em;
    }

    .card-text {
        clear: both;
        margin-top: .5em;
        color: rgba(0, 0, 0, .68);
    }

    .card-footer {
        font-size: 1em;
        position: static;
        top: 0;
        left: 0;
        max-width: 100%;
        padding: .75em 1em;
        color: rgba(0, 0, 0, .4);
        border-top: 1px solid rgba(0, 0, 0, .05) !important;
        background: #fff;
    }

    .card-inverse .btn {
        border: 1px solid rgba(0, 0, 0, .05);
    }

    .profile {
        position: absolute;
        top: -12px;
        display: inline-block;
        overflow: hidden;
        box-sizing: border-box;
        width: 25px;
        height: 25px;
        margin: 0;
        border: 1px solid #fff;
        border-radius: 50%;
    }

    .profile-avatar {
        display: block;
        width: 100%;
        height: auto;
        border-radius: 50%;
    }

    .profile-inline {
        position: relative;
        top: 0;
        display: inline-block;
    }

    .profile-inline ~ .card-title {
        display: inline-block;
        margin-left: 4px;
        vertical-align: top;
    }

    .text-bold {
        font-weight: 700;
    }

    .meta {
        font-size: 1em;
        color: rgba(0, 0, 0, .4);
    }

    .meta a {
        text-decoration: none;
        color: rgba(0, 0, 0, .4);
    }

    .meta a:hover {
        color: rgba(0, 0, 0, .87);
    }
    .card{position:relative;
        display:-webkit-box;
        display:-ms-flexbox;
        display:flex;
        -webkit-box-orient:vertical;
        -webkit-box-direction:normal;
        -ms-flex-direction:column;
        flex-direction:column;
        min-width:0;word-wrap:break-word;
        background-color:#fff;
        background-clip:border-box;
        border:1px solid rgba(0,0,0,.125);
        border-radius:.25rem}

    .card>hr{margin-right:0
    ;margin-left:0}

    .card>.list-group:first-child .list-group-item:first-child{border-top-left-radius:.25rem;border-top-right-radius:.25rem}

    .card>.list-group:last-child .list-group-item:last-child{border-bottom-right-radius:.25rem;border-bottom-left-radius:.25rem}

    .card-body{-webkit-box-flex:1;-ms-flex:1 1 auto;flex:1 1 auto;padding:1.25rem}

    .card-title{margin-bottom:.75rem}

    .card-subtitle{margin-top:-.375rem;margin-bottom:0}

    .card-text:last-child{margin-bottom:0}

    .card-link:hover{text-decoration:none}

    .card-link+.card-link{margin-left:1.25rem}

    .card-header{padding:.75rem 1.25rem;margin-bottom:0;background-color:rgba(0,0,0,.03);border-bottom:1px solid rgba(0,0,0,.125)}

    .card-header:first-child{border-radius:calc(.25rem - 1px) calc(.25rem - 1px) 0 0}

    .card-header+.list-group .list-group-item:first-child{border-top:0}

    .card-footer{padding:.75rem 1.25rem;background-color:rgba(0,0,0,.03);border-top:1px solid rgba(0,0,0,.125)}

    .card-footer:last-child{border-radius:0 0 calc(.25rem - 1px) calc(.25rem - 1px)}

    .card-header-tabs{margin-right:-.625rem;margin-bottom:-.75rem;margin-left:-.625rem;border-bottom:0}

    .card-header-pills{margin-right:-.625rem;margin-left:-.625rem}

    .card-img-overlay{position:absolute;top:0;right:0;bottom:0;left:0;padding:1.25rem}

    .card-img{width:100%;border-radius:calc(.25rem - 1px)}

    .card-img-top{width:100%;border-top-left-radius:calc(.25rem - 1px);border-top-right-radius:calc(.25rem - 1px)}

    .card-img-bottom{width:100%;border-bottom-right-radius:calc(.25rem - 1px);border-bottom-left-radius:calc(.25rem - 1px)}

    .card-deck{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}

    .card-deck

    .card{margin-bottom:15px}@media (min-width:576px){.card-deck{-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-flow:row wrap;flex-flow:row wrap;margin-right:-15px;margin-left:-15px}

    .card-deck .card{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-flex:1;-ms-flex:1 0 0%;flex:1 0 0%;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;margin-right:15px;margin-bottom:0;margin-left:15px}}

    .card-group{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}

    .card-group>.card{margin-bottom:15px}@media (min-width:576px){.card-group{-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-flow:row wrap;flex-flow:row wrap}

        .card-group>.card{-webkit-box-flex:1;-ms-flex:1 0 0%;flex:1 0 0%;margin-bottom:0}.card-group>.card+.card{margin-left:0;border-left:0}

        .card-group>.card:first-child{border-top-right-radius:0;border-bottom-right-radius:0}

        .card-group>.card:first-child .card-header,.card-group>.card:first-child

        .card-img-top{border-top-right-radius:0}

        .card-group>.card:first-child .card-footer,.card-group>.card:first-child .card-img-bottom{border-bottom-right-radius:0}.card-group>.card:last-child{border-top-left-radius:0;border-bottom-left-radius:0}.card-group>.card:last-child .card-header,.card-group>.card:last-child .card-img-top{border-top-left-radius:0}.card-group>.card:last-child .card-footer,.card-group>.card:last-child .card-img-bottom{border-bottom-left-radius:0}.card-group>.card:only-child{border-radius:.25rem}.card-group>.card:only-child .card-header,.card-group>.card:only-child .card-img-top{border-top-left-radius:.25rem;border-top-right-radius:.25rem}.card-group>.card:only-child .card-footer,.card-group>.card:only-child .card-img-bottom{border-bottom-right-radius:.25rem;border-bottom-left-radius:.25rem}.card-group>.card:not(:first-child):not(:last-child):not(:only-child){border-radius:0}.card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-footer,.card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-header,.card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-img-bottom,.card-group>.card:not(:first-child):not(:last-child):not(:only-child) .card-img-top{border-radius:0}}.card-columns .card{margin-bottom:.75rem}@media (min-width:576px){.card-columns{-webkit-column-count:3;-moz-column-count:3;column-count:3;-webkit-column-gap:1.25rem;-moz-column-gap:1.25rem;column-gap:1.25rem}.card-columns .card{display:inline-block;width:100%}}

    .vertical-align {
        display: flex;
        flex-direction: row;
    }

    .vertical-align > [class^="col-"],
    .vertical-align > [class*=" col-"] {
        display: flex;
        align-items: horizontal;
        /* justify-content: center; Optional, to align inner items
                                    horizontally inside the column */
    }
</style>


<div class="container">
    <div class=" vertical-align">


        <div class="col-sm-3 col-xs-4">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_bash.png">
                <div class="card-block">
                    <h4 class="card-title">App-Script</h4>
                    <div class="card-text">
                        Cette série d'épreuve vous confronte aux vulnérabilités liées à des faiblesses d'environnement, de configuration ou encore à des erreurs de développement dans des langages de script ou de programmation.
                    </div>
                </div>

            </div>
        </div>



        <div class="col-sm-3 col-xs-4">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_memory.png">
                <div class="card-block">
                    <h4 class="card-title">App-Systeme</h4>
                    <div class="card-text">
                        Cette série d'épreuve vous confronte aux vulnérabilités applicatives principalement liées aux erreurs de programmation aboutissant à des corruptions de zones mémoire.
                    </div>
                </div>
            </div>
        </div>


        <div class="col-sm-3 col-xs-4">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_cracking.png">
                <div class="card-block">
                    <h4 class="card-title">Cracking</h4>
                    <div class="card-text">
                        Ces challenges permettent de comprendre le sens du terme « langage compilé ». Ce sont des fichiers binaires à décortiquer pour aller chercher les instructions bas niveau permettant de répondre au problème posé.
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-3 col-xs-12">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_cryptanalyse.png">
                <div class="card-block">
                    <h4 class="card-title">Cryptanalyse</h4>
                    <div class="card-text">
                        Retrouvez les secrets protégés par des systèmes de chiffrement plus ou moins solides en réalisant des attaques cryptographiques.
                    </div>
                </div>
            </div>
        </div>

    </div>


</br>
</br>



    <div class="vertical-align">

        <div class="col-sm-3 col-xs-12">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_forensic.png">
                <div class="card-block">
                    <h4 class="card-title">Forensic</h4>
                    <div class="card-text">
                        Mettez à l'épreuve vos techniques d'investigations numériques en analysant des traces mémoire, des fichiers de journalisation, des captures réseaux...
                    </div>
                </div>
            </div>
        </div>


        <div class="col-sm-3 col-xs-12">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_programmation.png">
                <div class="card-block">
                    <h4 class="card-title">Programmation</h4>
                    <div class="card-text">
                        Automatisez des tâches de plus en plus complexes pour valider ces challenges en moins de quelques secondes.                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-3 col-xs-12">
            <div class="card card-inverse card-info">
                <img class="card-img-top" src="ressources\logo_breach\img_network.png">
                <div class="card-block">
                    <h4 class="card-title">Réseau</h4>
                    <div class="card-text">
                        Apprenez à analyser et à manipuler les différents protocoles et services les plus courants pour les tourner à votre avantage.
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-3 col-xs-12">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_stenography.png">
                <div class="card-block">
                    <h4 class="card-title">Stéganographie</h4>
                    <div class="card-text">
                        Si la cryptographie est l'art du secret, la stéganographie est l'art de la dissimulation : l'objet de la stéganographie n'est pas de rendre un message inintelligible aux personnes non autorisées mais de le faire passer inaperçu.                     </div>
                </div>
            </div>
        </div>

    </div>

</br>
</br>


    <div class="vertical-align">


        <div class="col-sm-3 col-sm-offset-3 col-xs-12">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_webclient.png">
                <div class="card-block">
                    <h4 class="card-title">Web Client</h4>
                    <div class="card-text">
                        Apprenez à exploiter les failles des applications web pour impacter leurs utilisateurs ou contourner des mécanismes de sécurité côté client.
                    </div>
                </div>
            </div>
        </div>


        <div class="col-sm-3 col-xs-12">
            <div class="card">
                <img class="card-img-top" src="ressources\logo_breach\img_webserver.png">
                <div class="card-block">
                    <h4 class="card-title">Web Serveur</h4>
                    <div class="card-text">
                        Ces épreuves vous permettront d'appréhender les techniques intrusives retrouvées sur le web, allant de l'exploitation de faiblesses de configuration jusqu'aux injections de code côté serveur.
                    </div>
                </div>
            </div>
        </div>

    </div>





</div>