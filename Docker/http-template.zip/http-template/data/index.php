<html>
<h1>
<center><?php echo gethostname(); ?></center>
</h1>
</html>